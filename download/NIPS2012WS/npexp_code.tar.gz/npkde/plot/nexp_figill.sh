#!/bin/sh


../bin/sof -n1000 -k1.5 -e"gaussian" -p0.001 -f"wsg.den" -l0.001 -a0
cp wsg.den wsg1.den
cp kernels.den kernels1.den
cp loglik.den logliks1.den
./plot.py wsg.den ../plot/rexp_n1000_e0.001_k1.5_a0.png kernels.den loglik.den

../bin/sof -n100 -k1 -e"gaussian" -p0.006 -f "wsg.den" -l0.001 -a0 --bimodel -s1
./plotg.py wsg.den ../plot/mexp_n100_sigma1_e0.006_k1.png kernels.den loglik.den
cp wsg.den wsg2.den
cp kernels.den kernels2.den
cp loglik.den logliks2.den
