#!/usr/bin/env python

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.collections as PatchCollection
import matplotlib.patches as mpatches
import numpy as np
import sys

if (len(sys.argv)<3):
    print 'Usage: %s <datafile> <outputfile>' %(sys.argv[0])
    print 'Doesn''t do error check, assumes paths are always correct.'
    sys.exit(0)
    
x=np.loadtxt(sys.argv[1])
kernels=np.loadtxt(sys.argv[3])
logliks=np.loadtxt(sys.argv[4])
den_t=x[:,1]
den_wn=x[:,2]
den_g=x[:,3]
den_sg=x[:,4]
den_ng=x[:,5]
x=x[:,0]
k=kernels
ky=-0.05*np.ones(len(kernels))
plt.plot(k,ky,'kx',markersize=3,label="Sample points")
plt.plot(x,den_t,'b',markersize=1,label="True distribution",linewidth=2.0)
#plt.plot(x,den_wn,'r.',markersize=1,label="KDE")
plt.plot(x,den_g,'r--',markersize=1,label="Gaussian",linewidth=2.0)
#plt.plot(x,den_sg,'k.',markersize=1,label="SPGaussian "+str(logliks[3]))
plt.plot(x,den_ng,'g-.',markersize=1,label="NPGaussian",linewidth=2.0)
plt.axis((-4,4,-0.1,0.45))
plt.xlabel('x')
plt.ylabel('pdf(x)')
plt.title(r'Estimation of t distribution, df=6', fontsize=16)
plt.legend(bbox_to_anchor=(0.67, 0.95), loc=2, borderaxespad=0., prop={'size':12})

plt.savefig(sys.argv[2], dpi=300)
