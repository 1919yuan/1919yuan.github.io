#!/usr/bin/env python

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.collections as PatchCollection
import matplotlib.patches as mpatches
import numpy as np
import sys

if (len(sys.argv)<1):
    print 'Usage: %s <datafile> <outputfile>' %(sys.argv[0])
    print 'Doesn''t do error check, assumes paths are always correct.'
    sys.exit(0)
    
x1=np.loadtxt("../bin/wsg_n10_bexp.den");
x2=np.loadtxt("../bin/wsg_n100_bexp.den");
x3=np.loadtxt("../bin/wsg_n1000_bexp.den");
kernels1=np.loadtxt("../bin/kernels_n10_bexp.den");
kernels2=np.loadtxt("../bin/kernels_n100_bexp.den");
kernels3=np.loadtxt("../bin/kernels_n1000_bexp.den");
logliks1=np.loadtxt("../bin/loglik_n10_bexp.den");
logliks2=np.loadtxt("../bin/loglik_n100_bexp.den");
logliks3=np.loadtxt("../bin/loglik_n1000_bexp.den");

den_t1=x1[:,1]
#den_wn=x[:,2]
den_g1=x1[:,2]
#den_sg=x[:,4]
den_ng1=x1[:,5]

den_t2=x2[:,1]
#den_wn=x[:,2]
den_g2=x2[:,2]
#den_sg=x[:,4]
den_ng2=x2[:,5]

den_t3=x3[:,1]
#den_wn3=x[:,2]
den_g3=x3[:,2]
#den_sg=x[:,4]
den_ng3=x3[:,5]

x=x1[:,0]
ky1=-0.1*np.ones(len(kernels1))
ky2=-0.2*np.ones(len(kernels2))
ky3=-0.3*np.ones(len(kernels3))

plt.plot(kernels1,ky1,'kx',markersize=3,label="Sample points")
plt.plot(kernels2,ky2,'kx',markersize=3)
plt.plot(kernels3,ky3,'kx',markersize=3)
plt.plot(x,den_t1+0.6,'b',markersize=1,label="True distribution",linewidth=2.0)
plt.plot(x,den_t1+0.3,'b',markersize=1,linewidth=2.0)
plt.plot(x,den_t1,'b',markersize=1,linewidth=2.0)
plt.plot(x,den_g1+0.6,'r--',markersize=1,label="KDE", linewidth=2.0)
plt.plot(x,den_ng1+0.6,'g-.',markersize=1,label="NPGaussian", linewidth=2.0)
plt.plot(x,den_g2+0.3,'r--',markersize=1,linewidth=2.0)
plt.plot(x,den_ng2+0.3,'g-.',markersize=1,linewidth=2.0)
plt.plot(x,den_g3,'r--',markersize=1,linewidth=2.0)
plt.plot(x,den_ng3,'g-.',markersize=1,linewidth=2.0)


#plt.plot(x,den_g,'g.',markersize=1,label="Gaussian "+str(logliks[2]))
#plt.plot(x,den_sg,'k.',markersize=1,label="SPGaussian "+str(logliks[3]))
#plt.plot(x,den_ng,'g.',markersize=1,label="NPGaussian "+str(logliks[4]))
plt.axis((-7,7,-0.33,1.2))
plt.xlabel('x')
plt.ylabel('pdf(x)')
plt.gca().axes.get_yaxis().set_visible(False)
plt.title(r'Mixed normal distribution, $\mu_1=-3$, $\mu_2=3$, $\sigma=1$', fontsize=16)
leg=plt.legend(bbox_to_anchor=(0.5, 1), loc="upper center", ncol=4, fancybox=True, borderaxespad=0., prop={'size':11})

plt.text(-6.5, 0.1, "n=1000", ha='left', rotation=0,fontsize=12)
plt.text(-6.5, 0.7, "n=10", ha='left', rotation=0,fontsize=12)
plt.text(-6.5, 0.4, "n=100", ha='left', rotation=0,fontsize=12)
plt.text(-6.5, -0.08, "n=10", ha='left', rotation=0,fontsize=12)
plt.text(-6.5, -0.18, "n=100", ha='left', rotation=0,fontsize=12)
plt.text(-6.5, -0.28, "n=1000", ha='left', rotation=0,fontsize=12)

#plt.gca().set_position([0.1,0.1,0.5,0.8])
plt.savefig(sys.argv[1], dpi=300)
