#include "svm_common.hh"
#include <fstream>
#include <iostream>
#include <sstream>

namespace by{

    SvmDoc::SvmDoc(const std::string svmfile, int s, int v):scale(s),verbosity_(v)
    {
        verbosity_=v;
        long dnum=0,dpos=0,dneg=0,dunlab=0;
        //long int maxwords,maxdoc,linelength;
        //nol_ll_(svmfile,maxdoc,maxwords,linelength);
        //std::cout << maxdoc << ":" << maxwords << ":" << linelength << std::endl;
        std::ifstream infile(svmfile.c_str());
        std::string line;
        totwords=0;
        totdoc=0;
        getline(infile,line);
        while (!line.empty())
        {
            if (line[0]=='#')
            {
                getline(infile,line);
                continue;
            }
            std::stringstream ss(line);
            
            int l;
            ss >> l;
            label.push_back(l);
            if (l>0) dpos++;
            else if (l<0) dneg++;
            else dunlab++;
            SVECTOR tmpVec;
            while (ss.good())
            {
                WORD tmpWord;
                ss >> tmpWord.wnum;
                if (tmpWord.wnum > totwords) totwords=tmpWord.wnum;
                char tmpC;
                ss.read(&tmpC,1);
                ss >> tmpWord.weight;
                tmpWord.weight = tmpWord.weight / scale;
                tmpVec.words.push_back(tmpWord);
            }
            totdoc++;
            fvec.push_back(tmpVec);
            getline(infile,line);
        }
    } 

    void SvmDoc::nol_ll_(const std::string& file, long int& maxdoc, long int& maxwords, long int& ll)
    {
        std::ifstream fl(file.c_str());
        char c;
        long current_length,current_wol;

        if (!fl.is_open())
        { std::cerr << "File " << file << "not found." << std::endl; exit (1); }
        current_length=0;
        current_wol=0;
        std::string line;
        maxdoc=1;
        maxwords=0;
        ll=0;
        while(fl.good()) 
        {
            fl.read(&c,1);
            current_length++;
            if((int)c==0 || std::isspace((unsigned char) c)) {
                current_wol++;
            }
            if(c == '\n') {
                maxdoc++;
                if(current_length>ll) {
                    ll=current_length;
                }
                if(current_wol>maxwords) {
                    maxwords=current_wol;
                }
                current_length=0;
                current_wol=0;
            }
        }
        fl.close();
    }

}

