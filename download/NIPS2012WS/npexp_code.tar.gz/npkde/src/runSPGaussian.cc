#include <iostream>
#include <fstream>
#include <vector>
#include <Eigen/Dense>
#include "svm_common.hh"
#include "SPGaussian.hh"

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include "getopt.h"
#else 
#include <unistd.h>
#endif 

static int verbose_flag;
static int train_flag;
static int test_flag;
static int rmodel_flag;
static int smodel_flag;

static char help_msg[] = 
"Usage: runSPGaussian [-d TrainFileName] [-t TestFileName] [-p SavedTrainParamFile] [-s OutputTrainParamFile] [-h] [--verbose]\n\
  -h [ --help ]: print this help.\n\
  -d [ --train ] TrainFileName: set the training input file.\n\
  -t [ --test ] TestFileName: set the testing input file.\n\
  -p [ --rmodel ] SavedTrainParamFile: set the file to read in the trained model.\n\
  -s [ --smodel ] OutputTrainParamFile: set the output file to save the trained model.\n\
  [ --verbose ]: verbose flag.\n\
";

int main(int argc, char** argv)
{
    int c;
    std::string trainFile;
    std::string testFile;
    std::string rmodelFile;
    std::string smodelFile;
    //std::string oFile;
    static struct option long_options[]=
    {
        {"verbose", no_argument, &verbose_flag, 1},
        {"train", required_argument, 0, 'd'},
        {"test", required_argument, 0, 't'},
        {"rmodel", required_argument, 0, 'p'},
        {"smodel", required_argument, 0, 's'},
        {0,0,0,0}
    };

    int option_index=0;
    
    int errflg=0;
    while ((c = getopt_long(argc, argv, "d:t:s:p:h",long_options,&option_index)) != -1)
    {
        switch (c) {
        case 0:
            break;
        case 'd':
            trainFile=std::string(optarg);
            train_flag=1;
            break;
        case 't':
            test_flag=1;
            testFile=std::string(optarg);
            break;
        case 'p':
            rmodel_flag=1;
            rmodelFile=std::string(optarg);
            break;
        case 's':
            smodel_flag=1;
            smodelFile=std::string(optarg);
            break;
        case '?':
            errflg++;
            break;
        default:
            errflg++;
            break;
        }
        
    }
    /*ConfigFile config;
    try
    {
        config=ConfigFile(configfile.c_str());
    }
    catch (ConfigFile::file_not_found)
    {
        errflg++;
        std::cerr << configfile << " not found!" << std::endl;
    }*/
    if (errflg || argc == 1) {
        std::cout << help_msg << std::endl;
        exit (0);
    }
    if (train_flag && test_flag)
    {
        by::SvmDoc sdoc(trainFile,1);
        Eigen::MatrixXd x_train(sdoc.totdoc,sdoc.totwords);
        for (int i=0; i<sdoc.totdoc; i++)
        {
            x_train(i,0)=sdoc.fvec[i].words[0].weight;
            sdoc.label[i] = (sdoc.label[i]+1)/2;
        }
        by::SvmDoc tdoc(testFile,1);
        Eigen::MatrixXd x_test(tdoc.totdoc,tdoc.totwords);
        for (int i=0; i<tdoc.totdoc; i++)
        {
            x_test(i,0)=tdoc.fvec[i].words[0].weight;
            tdoc.label[i] = (tdoc.label[i]+1)/2;
        }
        by::SPGaussian spgaussianclassifier;
        spgaussianclassifier.init(2, 0.6, 1, 1);
        std::vector<int> y_test = spgaussianclassifier.classify(x_train, sdoc.label, x_test);
        int numWrong = 0;
        for (int i=0; i<tdoc.totdoc; i++)
        {
            if (y_test[i] != tdoc.label[i]) numWrong++;
        }
        std::cout << "Numwrong: " << numWrong << "/" << tdoc.totdoc << std::endl;
    }
    else{
        //TODO: save and read parameters.
    }
    /*if (test_flag)
    {
        if (!pLogReg)
        {
            if (!rmodel_flag)
            {
                std::cerr << "No input training database or parameter file specified, cannot do testing." << std::endl;
                return 1;
            }
            else
            {
                pLogReg = new LogReg(0);
                pLogReg->readParam(rmodelFile);
            }
        }
        if (pLogReg)
        {
            SvmDoc tdoc(testFile);
            std::vector<int> labels;
            pLogReg->test(tdoc,labels);
            int numWrong=0;
            for (unsigned int i=0; i<labels.size(); i++)
            {
                if (labels[i]!=tdoc.label[i]) numWrong++;
            }
            std::cout << "NumWrong: " << numWrong << ":" << labels.size() << std::endl;
        }
    }
    if (!pLogReg) delete pLogReg;*/
}
