#include "MSNPGaussian.hh"
#include "Normal.hh"
#include "StudentT.hh"
#include <Eigen/Dense>
#include <vector>
#include <cmath>
#include <iostream>
#include <boost/math/distributions/normal.hpp>

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include <random>
#else
#include <stdlib.h>
#endif

namespace by{

    MSNPGaussian::MSNPGaussian():verbose_(false)
    {
        seed_ = 2341;
        init(2,0.1,1,0.1,1000,"gaussian",0.01,10);
    }

    MSNPGaussian::MSNPGaussian(int nc, int seed):verbose_(false)
    {
        seed_ = seed;
        init(nc,0.1,1,0.1,1000,"gaussian",0.01,10);
    }
    void MSNPGaussian::init(int nc, double p_lower_scale, double np_portion, double epsilon, int MC_NUM, std::string kerType, double gdiffthres, double l2alpha)
    {
        //double maxkerfunc = 1/std::sqrt(2*3.1415926);
        nc_=nc;
        //p_lower_=p_lower*maxkerfunc;
        l2alpha_ = l2alpha;
        membershipTol_=p_lower_scale;
        p_lower_scale_=p_lower_scale;
        np_portion_=np_portion;
        epsilon_=epsilon;
        MC_NUM_=MC_NUM;
        gdiffthres_=gdiffthres;
        steplimit_=5;
        if (!kerType.compare("gaussian"))
            kerType_=gaussian;
        else if (!kerType.compare("uniform"))
            kerType_=uniform;
        else kerType_=gaussian;
        //kerFuncMax_ = std::sqrt(1/(2*PI));
        //kerType_ = uniform;
        kerFuncMax_ = 1;
        //REGSIGMA!!!
        regularizeMu_ = true;
        regularizeSigma_ = true;
        regularizeExtra_ = true;

        //Calculating kerScale_
        sep_=1000;
        start_=-10;
        end_=10;
        //if (kerType_==gaussian)
        //{
        //    double gsum = 0;
        //    for (int i=0; i<sep_; i++)
        //    {
        //        double ind_x=start_+(end_-start_)/sep_*i+(end_-start_)/sep_/2;
        //        gsum+=(1/std::sqrt(2*PI)*std::exp(-0.5*(ind_x)*(ind_x)/epsilon_/epsilon_));
        //    }
        //    kerScale_ = epsilon_*(sep_/(end_-start_))/gsum;
        //}
        //else if (kerType_==uniform)
        //{
        //    kerScale_ = 1;//2*epsilon_*(sep_/(end_-start_));
        //}

        //estMethod_=MonteCarlo;
        estMethod_=Quadrito;
    }
//     std::vector<int> SPGaussian::classify(const Eigen::MatrixXd& x_train, 
//         const std::vector<int>& y_train, const Eigen::MatrixXd& x_test)
//     {
//         //std::cout << x_train;
//         std::vector<Eigen::MatrixXd*> x_train_split;
//         std::vector<int> count(nc_);
//         for (int i=0;i<nc_;i++) count[i]=0;
//         for (unsigned int i=0;i<y_train.size();i++)
//             count[y_train[i]]+=1;
//         for (int i=0;i<nc_;i++)
//         {
//             Eigen::MatrixXd* mptr = new Eigen::MatrixXd(count[i],x_train.cols());
//             x_train_split.push_back(mptr);
//         }
//         for (int i=0;i<nc_;i++) count[i]=0;
//         for (unsigned int i=0;i<y_train.size();i++)
//         {
//             Eigen::MatrixXd* a = x_train_split[y_train[i]];
//             a->row(count[y_train[i]]++)=x_train.row(i);
//         }
//         std::vector<int> y_test(x_test.rows());
//         for (int i=0; i < x_test.rows(); i++) y_test[i]=0;

//         if (x_test.cols()==1)
//         {
//             std::vector<SPGaussianParam1d> params(nc_);
//             for (int i=0; i<nc_; i++)
//             {
//                 params[i]=getModel1d(*x_train_split[i]);
//             }
//             for (int i=0;i<x_test.rows();i++)
//             {
//                 double x = x_test(i,0);
//                 y_test[i]=calcMaxPdf1d(x,params);
//             }
//         }
//         else{
//             //TODO;
//         }
//         for (int i=0; i<nc_; i++) delete x_train_split[i];
//         return y_test;
//     }

    MSNPGaussian::MSNPGaussianParam1d MSNPGaussian::getModel1d(const Eigen::MatrixXd& x)
    {
        //std::cout << x;
        int iter = 0;
        MSNPGaussianParam1d ngp;
        findKernels1d(x,np_portion_,epsilon_,ngp);
        Eigen::VectorXd obs(ngp.kernels.rows()+2);
        findObs1d(obs,x,ngp);
        if (verbose_) std::cout << "obs: " << obs.transpose() <<std::endl;
        obs(0)=prior1m_;
        obs(1)=prior2m_;
        ngp.mu = obs(0);
        ngp.sigma = std::sqrt(obs(1)-obs(0)*obs(0));
        //coordinate descent loop;
        ngp.lambda1 = ngp.mu/ngp.sigma/ngp.sigma;
        ngp.lambda2 = -0.5/ngp.sigma/ngp.sigma;
        ngp.lambda = 0;
        double normdiff = 10;
        double normdiff_ball = 10;
        double normdiff_feature = 10;
        int i=0;
        Eigen::VectorXd expectation(ngp.kernels.rows()+2);
        Eigen::VectorXd variance(ngp.kernels.rows()+2);
        //KERNEL
        //uniform
        //p_lower_ = (double)1/ngp.kernels.rows()/kerFuncMax_;
        //gaussian
        //p_lower_ = (double)4/ngp.kernels.rows();
        //RATIO
        //p_lower_ = 0.2;
        //p_lower_ = p_lower_scale_*1.0/ngp.kernels.rows()/kerFuncMax_;
        //p_lower_ = p_lower_scale_/kerFuncMax_;

        if (estMethod_ == Quadrito)
            findDensity1d(ngp);
        bool changeindicator = 1;
        while (1)
        {
            if (changeindicator == 1)
            {
                findDensity1d(ngp);
                pKernels1d(ngp, expectation, variance);
            }
            //normdiff = getNormDiff(obs,expectation);
            normdiff_ball = getNormDiff_ball(obs,expectation);
            normdiff_feature = getNormDiff_feature(obs,expectation,ngp);
            //std::cout << "Current Lambda:" << std::endl;
            //std::cout << ngp.lambdas;
            if (changeindicator == 1 && verbose_)
                std::cout << "Iter " << iter << "-" << i << ": Diff_ball: " << normdiff_ball << " Diff_feature: " <<normdiff_feature << std::endl;
            if (((normdiff_feature < 5*gdiffthres_) && (normdiff_ball < gdiffthres_ ))|| iter > 2)
            //if (( (normdiff_ball < gdiffthres_ ))|| iter > 5)
                break;
            if (i==0)
            {
                //i=i+1;
                //continue;
                if (!regularizeMu_)
                {
                    double neg_grad = obs(i)-expectation(i);//expectation(i)-obs(i);
                    //double neg_grad = obs(i) - expectation(i) + l2alpha_*ngp.lambda1;
                    double alpha = 1/(variance(i));
                    double stepsize = neg_grad*alpha;
                    if (stepsize > steplimit_) stepsize = steplimit_;
                    else if (stepsize < -steplimit_) stepsize = -steplimit_;
                    else ;
                    ngp.lambda1+=stepsize;
                    ngp.mu = -0.5*ngp.lambda1/ngp.lambda2;
                    //ngp.sigma = std::sqrt(-0.5/ngp.lambda2);
                    changeindicator = 1;
                }
                else
                {
                    //double neg_grad = obs(i)-expectation(i);//expectation(i)-obs(i);
                    double neg_grad = obs(i) - expectation(i) - l2alpha_*ngp.lambda1;
                    double alpha = 1/(variance(i)+l2alpha_);
                    double stepsize = neg_grad*alpha;
                    if (stepsize > steplimit_) stepsize = steplimit_;
                    else if (stepsize < -steplimit_) stepsize = -steplimit_;
                    else ;
                    ngp.lambda1+=stepsize;
                    ngp.mu = -0.5*ngp.lambda1/ngp.lambda2;
                    ngp.sigma = std::sqrt(-0.5/ngp.lambda2);
                    changeindicator = 1;
                }
            }
            else if (i==1)
            {
                //i=i+1;
                //changeindicator = false;
                //continue;
                if (!regularizeSigma_)
                {
                    //double neg_grad = obs(i) - expectation(i) + l2alpha_*ngp.lambda2;
                    double neg_grad = obs(i)-expectation(i);//expectation(i)-obs(i);
                    double alpha = 1/variance(i);
                    double stepsize = neg_grad*alpha;
                    if (stepsize > steplimit_) stepsize = steplimit_;
                    else if (stepsize < -steplimit_) stepsize = -steplimit_;
                    else ;
                    if (ngp.lambda2+stepsize >= 0) ngp.lambda2+=-0.1*ngp.lambda2;
                    else ngp.lambda2+=stepsize;
                    if (ngp.lambda2 >= 0)
                    {
                        std::cerr << "positive sigma, no integral!" << std::endl;
                        exit(1);
                    }
                    //std::assert(ngp.lambda2 < 0);
                    ngp.mu = -0.5*ngp.lambda1/ngp.lambda2;
                    ngp.sigma = std::sqrt(-0.5/ngp.lambda2);
                    changeindicator = 1;
                }
                // else
//                 {
//                     double neg_grad = obs(i) - expectation(i) - l2alpha_*(ngp.lambda2+0.5);
//                     //double neg_grad = obs(i)-expectation(i);//expectation(i)-obs(i);
//                     double alpha = 1/(variance(i)+l2alpha_);
//                     double stepsize = neg_grad*alpha;
//                     if (stepsize > steplimit_) stepsize = steplimit_;
//                     else if (stepsize < -steplimit_) stepsize = -steplimit_;
//                     else ;
//                     if (ngp.lambda2+stepsize >= 0) ngp.lambda2+=-0.1*ngp.lambda2;
//                     else ngp.lambda2+=stepsize;
//                     if (ngp.lambda2 >= 0)
//                     {
//                         std::cerr << "positive sigma, no integral!" << std::endl;
//                         exit(1);
//                     }
//                     //std::assert(ngp.lambda2 < 0);
//                     ngp.mu = -0.5*ngp.lambda1/ngp.lambda2;
//                     ngp.sigma = std::sqrt(-0.5/ngp.lambda2);
//                     changeindicator = 1;
//                 }
                else
                {
                   //REGSIGMA!!!
                   double lambdaV = solveForVariance(ngp,obs(1));
                   if (lambdaV < 0)
                   {
                       //double delta_plus = std::log((p_lower_ * (1-p))/(1-p_lower_)/p);
                       //double stepsize = lambdaV-ngp.lambda2;
                       //if (stepsize > steplimit_) stepsize = steplimit_;
                       //else if (stepsize < -steplimit_) stepsize = -steplimit_;
                       //else ;
                       ngp.lambda2=lambdaV;
                       ngp.mu = -0.5*ngp.lambda1/ngp.lambda2;
                       ngp.sigma = std::sqrt(-0.5/ngp.lambda2);
                       changeindicator = 1;
                   }
                   else
                   {
                       std::cerr << "positive sigma, no integral!" << std::endl;
                       exit(1);
                       //if (lambdaV!=ngp.lambda2)
                       //{
                       //   ngp.lambda2 = 0;
                       //   changeindicator = 1;
                       //}
                   }
                }
            }
            else {
                //double p = expectation(i)/obs(i);
                //double p = expectation(i)/kerFuncMax_;
                //std::cout << "Coordinate " << i << ": Exp: " << expectation(i) << ", Obs: " << obs(i) << std::endl;

                //KERNEL
                //kerFuncMax_ = expectation.tail(expectation.rows()-2).maxCoeff();
                if (!regularizeExtra_)
                {
                    double neg_grad = obs(i)-expectation(i);//expectation(i)-obs(i);
                    double alpha = 1/variance(i);
                    double stepsize = neg_grad*alpha;
                    if (stepsize > steplimit_) stepsize = steplimit_;
                    else if (stepsize < -steplimit_) stepsize = -steplimit_;
                    else ;
                    ngp.lambdas(i-2)+=stepsize;
                }
                else{
                    double lambdai = solveForLambda(ngp,i-2,obs);
                    if (lambdai != 0)
                    {
                        //double delta_plus = std::log((p_lower_ * (1-p))/(1-p_lower_)/p);
                        double stepsize = lambdai-ngp.lambdas(i-2);
                        if (stepsize > steplimit_) stepsize = steplimit_;
                        else if (stepsize < -steplimit_) stepsize = -steplimit_;
                        else ;
                        ngp.lambdas(i-2)=ngp.lambdas(i-2)+stepsize;
                        changeindicator = 1;
                    }
                    else
                    {
                        double stepsize = -ngp.lambdas(i-2);
                        if (stepsize > steplimit_) stepsize = steplimit_;
                        else if (stepsize < -steplimit_) stepsize = -steplimit_;
                        else ;
                        ngp.lambdas(i-2)=ngp.lambdas(i-2)+stepsize;
                        if (stepsize == 0) changeindicator = 0;
                        else changeindicator = 1;
                        //changeindicator = 0;
                    }
                }
            }
            //std::cout << "i: " << i << "lambdas: [" << ngp.mu << "," << ngp.sigma << "], " << ngp.lambdas << std::endl; 
            i=i+1;
            if (i==ngp.lambdas.size()+2) 
            {
                i=0;
                iter = iter+1;
            }
        }
        
//         double p = pKernels1d(ngp);
//         double delta_plus = std::log((p_lower_ * (1-p))/(1-p_lower_)/p);
//         while ( p < p_lower_ && std::fabs(delta_plus)> 0.0001)
//         {
//             if (sgp.lambda + delta_plus > 0) sgp.lambda += delta_plus;
//             else sgp.lambda = 0;
//             p = pKernels1d(sgp);
//             delta_plus = std::log((p_lower_ * (1-p))/(1-p_lower_)/p);
//         }
        if (estMethod_==Quadrito) 
        {
            //findDensity1d(ngp);
            if (ngp.lambda2<0)
                reCalcPartition(ngp);
            //REGSIGMA!!!
            else reCalcPartition_T(ngp);
        }
        return ngp;
    }

    void MSNPGaussian::findKernels1d(const Eigen::MatrixXd& x, double portion, double epsilon, MSNPGaussianParam1d& ngp)
    {
        srand(seed_);
        std::vector<double> x_chosen;
        for (int i=0; i<x.rows(); i++)
        {
            if (rand() <= portion*((double)RAND_MAX+1))
                //&& std::fabs(x(i,0)) > 5)
                // && std::fabs(x(i,0)-sgp.mu) > sgp.sigma/2 )
                x_chosen.push_back(x(i,0));
        }
        if (x_chosen.empty()) 
        {
            std::cerr << "No kernels were select from training set, check your portion parameter, make sure it is not too small." << std::endl;
            exit(-1);
        }
        ngp.kernels=Eigen::VectorXd(x_chosen.size());
        ngp.lambdas=Eigen::VectorXd(x_chosen.size());
        for (unsigned int i=0; i<x_chosen.size(); i++) 
        {
            ngp.kernels(i)=x_chosen[i];
            ngp.lambdas(i)=0;
        }        
    }

    void MSNPGaussian::findDensity1d(MSNPGaussianParam1d& ngp)
    {
        int start=start_;
        int end=end_;
        double sep=sep_;
        ngp.density=Eigen::MatrixX2d((int)sep,2);
        ngp.par = 1;
        for (int i=0; i<sep; i++)
        {
            ngp.density(i,0)=start+(end-start)/(double)sep*i+(end-start)/(double)sep/2;
            ngp.density(i,1)=MSNPGaussianPdf(ngp.density(i,0),ngp);
            //if (ngp.density(i,1) > 0.01/std::sqrt(2*PI))
            //    break;
        }
        ngp.par = 0;
        for (int i=0; i<sep; i++)
            ngp.par += ngp.density(i,1);
    }

    double MSNPGaussian::solveForLambda(MSNPGaussianParam1d& ngp, int ki, const Eigen::VectorXd& obs)
    {
        Eigen::VectorXd weights(ngp.density.rows());
        Eigen::VectorXd kweights(ngp.density.rows());
        bool lowOK=false;
        bool highOK=false;
        for (int i=0; i<weights.size(); i++)
        {
            kweights(i)=kerFunc1d(ngp.density(i,0),ngp.kernels(ki));
        }
        weights = ngp.density.col(1);
        //std::cout <<"Ratio" << weights.maxCoeff()/weights.minCoeff() << std::endl;
        weights = weights*(1/ngp.par);
        //double target = p_lower_*kerFuncMax_;
        //double target = p_lower_*obs(ki+2)*kerFuncMax_;
        double target = obs(ki+2)-membershipTol_;
        double lstart = -50;
        double lend = 50;
        double vstart = getDeltaV(lstart-ngp.lambdas(ki),weights,kweights);
        double vend = getDeltaV(lend-ngp.lambdas(ki),weights,kweights);
        if ((vstart-target)*(vend-target) > 0) 
        {
            if (vstart > target)
                lowOK=true;
            else
            {
                std::cerr << " no solution!" << std::endl;
                return lend;
            }
        }
        double lmid=0;
        while(std::fabs(vend-target)>0.001 && !lowOK)
        {
            lmid = (lend+lstart)/2;
            double vmid = getDeltaV(lmid-ngp.lambdas(ki),weights,kweights);
            if (vmid < target)
            {
                vstart = vmid;
                lstart = lmid;
            }
            else {
                vend = vmid;
                lend = lmid;
            }
        }
        if (lmid <= 0) lowOK = true;
        else return lmid;
        target = obs(ki+2)+membershipTol_;
        lstart = -50;
        lend = 50;
        vstart = getDeltaV(lstart-ngp.lambdas(ki),weights,kweights);
        vend = getDeltaV(lend-ngp.lambdas(ki),weights,kweights);
        if ((vstart-target)*(vend-target) > 0) 
        {
            if (vend < target)
                highOK = true;
            else
            {
                std::cerr << " no solution!" << std::endl;
                return lend;
            }
        }
        lmid=0;
        while(std::fabs(vend-target)>0.001 && !highOK)
        {
            lmid = (lend+lstart)/2;
            double vmid = getDeltaV(lmid-ngp.lambda2,weights,kweights);
            if (vmid < target)
            {
                vstart = vmid;
                lstart = lmid;
            }
            else {
                vend = vmid;
                lend = lmid;
            }
        }
        if (lmid >= 0) highOK = true;
        else return lmid;
        return 0;
    }

    double MSNPGaussian::solveForVariance(MSNPGaussianParam1d& ngp, double var)
    {
        Eigen::VectorXd weights(ngp.density.rows());
        Eigen::VectorXd kweights(ngp.density.rows());
        bool lowOK=false;
        bool highOK=false;
        for (int i=0; i<weights.size(); i++)
        {
            kweights(i)=ngp.density(i,0)*ngp.density(i,0);
        }
        weights = ngp.density.col(1);
        //std::cout <<"Ratio" << weights.maxCoeff()/weights.minCoeff() << std::endl;
        weights = weights*(1/ngp.par);
        double target = var;
        double lstart = -10000;
        double lend = -0.0001;
        double vstart = getDeltaV(lstart-ngp.lambda2,weights,kweights);
        double vend = getDeltaV(lend-ngp.lambda2,weights,kweights);
        if ((vstart-target)*(vend-target) > 0) 
        {
            //if (vstart > target)
            //    lowOK = true;
            //else
            //{
            std::cerr << " no solution!" << std::endl;
            //exit(1);
            return lend;
            //}
        }
        double lmid=0;
        while(std::fabs(vend-target)>0.001)
        {
            lmid = (lend+lstart)/2;
            double vmid = getDeltaV(lmid-ngp.lambda2,weights,kweights);
            if (vmid < target)
            {
                vstart = vmid;
                lstart = lmid;
            }
            else {
                vend = vmid;
                lend = lmid;
            }
        }
        return lmid;
    }

    ///*double NPGaussian::solveForLambda(NPGaussianParam1d& ngp, int ki)
    //{
    //    Eigen::VectorXd weights(ngp.density.rows());
    //    Eigen::VectorXd kweights(ngp.density.rows());
    //    for (int i=0; i<weights.size(); i++)
    //    {
    //        kweights(i)=kerFunc1d(ngp.density(i,0),ngp.kernels(ki));
    //    }
    //    weights = ngp.density.col(1);
    //    std::cout <<"Ratio" << weights.maxCoeff()/weights.minCoeff() << std::endl;
    //    weights = weights*(1/ngp.par);
    //    double target = p_lower_*kerFuncMax_;
    //    double lstart = -10;
    //    double lend = 10;
    //    double vstart = getDeltaV(lstart-ngp.lambdas(ki),weights,kweights);
    //    double vend = getDeltaV(lend-ngp.lambdas(ki),weights,kweights);
    //    if ((vstart-target)*(vend-target) > 0) 
    //    {
    //        std::cerr << " no solution!" << std::endl;
    //        return lend;
    //    }
    //    double lmid=0;
    //    while(std::fabs(vend-target)>0.001)
    //    {
    //        lmid = (lend+lstart)/2;
    //        double vmid = getDeltaV(lmid-ngp.lambdas(ki),weights,kweights);
    //        if (vmid < target)
    //        {
    //            vstart = vmid;
    //            lstart = lmid;
    //        }
    //        else {
    //            vend = vmid;
    //            lend = lmid;
    //        }
    //    }
    //    return lmid;
    //}*/

    void MSNPGaussian::findObs1d(Eigen::VectorXd& obs, const Eigen::MatrixXd& x, const MSNPGaussianParam1d& ngp)
    {
        double mean = 0;
        double sd = 0;
        for (int i=0; i < x.rows(); i++)
        {
            mean += x(i,0);
        }
        mean /= x.rows();
        obs(0)=mean;
        for (int i=0; i < x.rows(); i++)
        {
            sd += (x(i,0))*(x(i,0));
        }
        sd /= x.rows();
        obs(1)=sd;
        for (int i=2; i < obs.rows(); i++)
        {
            mean = 0;
            for (int j=0; j < x.rows(); j++)
                mean+=kerFunc1d(x(j,0),ngp.kernels(i-2));
            mean /= x.rows();
            obs(i)=mean;
        }
    }

    void MSNPGaussian::reCalcPartition(MSNPGaussianParam1d& param)
    {
        by::Normal ngen = by::Normal(seed_);
        Eigen::MatrixXd data = ngen.NormalRandom(param.mu,param.sigma,MC_NUM_,1);
        Eigen::VectorXd kernelwight(MC_NUM_);
        double totexpgx = 0;
        double totexpmu = 0;
        double totexpsigma = 0;
        Eigen::VectorXd totexpm(param.lambdas.size());
        for (int i=0; i<MC_NUM_; i++)
        {
            kernelwight(i)=calcKernels1d(data(i,0),param)+Aeita(param)+std::log(2*PI)/2;
            totexpgx+=std::exp(kernelwight(i))/MC_NUM_;
        }
        param.par = totexpgx;
    }

    void MSNPGaussian::reCalcPartition_T(MSNPGaussianParam1d& param)
    {
        by::StudentT tgen = by::StudentT(seed_);
        Eigen::MatrixXd data = tgen.TDistRandom(0,6,MC_NUM_,1);
        Eigen::VectorXd kernelwight(MC_NUM_);
        double totexpgx = 0;
        for (int i=0; i<MC_NUM_; i++)
        {
            kernelwight(i)=calcKernels1d(data(i,0),param)+param.lambda1*data(i,0)+param.lambda2*data(i,0)*data(i,0);
            totexpgx+=std::exp(kernelwight(i))/MC_NUM_;
        }
        param.par = totexpgx;
    }

    void MSNPGaussian::pKernels1d(MSNPGaussianParam1d& ngp, Eigen::VectorXd& expectation, Eigen::VectorXd& variance)
    {
        //if (kerType_==uniform) // have closed form
        //{
        //    if (estMethod_ == Quadrito)
        //    {
        //        expectation(0)=0;
        //        variance(0)=0;
        //        for (int i=0; i<ngp.density.rows(); i++)
        //        {
        //            expectation(0)+=ngp.density(i,0)*ngp.density(i,1)/ngp.par;
        //            variance(0)+=ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,1)/ngp.par;
        //        }
        //        variance(0)-=expectation(0)*expectation(0);
        //        expectation(1)=0;
        //        variance(1)=0;
        //        for (int i=0; i<ngp.density.rows(); i++)
        //        {
        //            expectation(1)+=ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,1)/ngp.par;
        //            variance(1)+=ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,1)/ngp.par;
        //        }
        //        variance(1)-=expectation(1)*expectation(1);
        //        for (int j=2; j<ngp.lambdas.size()+2; j++)
        //        {
        //            expectation(j)=0;
        //            variance(j)=0;
        //            for (int i=0; i<ngp.density.rows(); i++)
        //            {
        //                double value = kerFunc1d(ngp.density(i,0),ngp.kernels(j-2));
        //                expectation(j)+=value*ngp.density(i,1)/ngp.par;
        //                variance(j)+=value*value*ngp.density(i,1)/ngp.par;
        //            }
        //            //if (expectation(j) > 5) 
        //            //    std::cout << "Anoamli" << std::endl;

        //            variance(j)-=expectation(j)*expectation(j);
        //        }
        //        //std::cout << "Expectation: " << expectation << std::endl;
        //    }
        //}
        //else 
        if (estMethod_ == MonteCarlo)//(kerType_==MSNPGaussianKerType::gaussian)
        {
            by::Normal ngen = by::Normal(seed_);
            Eigen::MatrixXd data = ngen.NormalRandom(ngp.mu,ngp.sigma,MC_NUM_,1);
            Eigen::VectorXd kernelwight(MC_NUM_);
            double totexpgx = 0;
            double totexpmu = 0;
            double totexpsigma = 0;
            Eigen::VectorXd totexpm(ngp.lambdas.size());
            for (int i=0; i<MC_NUM_; i++)
            {
                kernelwight(i)=calcKernels1d(data(i,0),ngp)+Aeita(ngp)+std::log(2*PI)/2;
                totexpgx+=std::exp(kernelwight(i))/MC_NUM_;
            }
            ngp.par = totexpgx;
            for (int i=0; i<MC_NUM_; i++)
            {
                kernelwight(i)=std::exp(kernelwight(i))/totexpgx;
            }
            expectation(0)=0;
            variance(0)=0;
            for (int i=0; i<MC_NUM_; i++)
            {
                expectation(0)+=kernelwight(i)*data(i,0);
                variance(0)+=kernelwight(i)*data(i,0)*data(i,0);
            }
            expectation(0)/=MC_NUM_;
            variance(0)/=MC_NUM_;
            variance(0)-=expectation(0)*expectation(0);
            expectation(1)=0;
            variance(1)=0;
            for (int i=0; i<MC_NUM_; i++)
            {
                expectation(1)+=kernelwight(i)*data(i,0)*data(i,0);
                variance(1)+=kernelwight(i)*data(i,0)*data(i,0)*data(i,0)*data(i,0);
            }
            expectation(1)/=MC_NUM_;
            variance(1)/=MC_NUM_;
            variance(1)-=expectation(1)*expectation(1);
            //std::cout << "Expectation:" << expectation << std::endl;
            for (int j=2; j<ngp.lambdas.size()+2; j++)
            {
                expectation(j)=0;
                variance(j)=0;
                for (int i=0; i<MC_NUM_; i++)
                {
                    double value = kerFunc1d(ngp.kernels(j-2),data(i,0));
                    expectation(j)+=kernelwight(i)*value;
                    variance(j)+=kernelwight(i)*value*value;
                }
                expectation(j)/=MC_NUM_;
                variance(j)/=MC_NUM_;
                variance(j)-=expectation(j)*expectation(j);
            }
            //std::cout << "Expectation:" << expectation << std::endl;
            return;
        }
        else //gaussian + quadrito
        {
            expectation(0)=0;
            variance(0)=0;
            for (int i=0; i<ngp.density.rows(); i++)
            {
                expectation(0)+=ngp.density(i,0)*ngp.density(i,1)/ngp.par;
                variance(0)+=ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,1)/ngp.par;
            }
            variance(0)-=expectation(0)*expectation(0);
            expectation(1)=0;
            variance(1)=0;
            for (int i=0; i<ngp.density.rows(); i++)
            {
                expectation(1)+=ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,1)/ngp.par;
                variance(1)+=ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,0)*ngp.density(i,1)/ngp.par;
            }
            variance(1)-=expectation(1)*expectation(1);
            for (int j=2; j<ngp.lambdas.size()+2; j++)
            {
                expectation(j)=0;
                variance(j)=0;
                for (int i=0; i<ngp.density.rows(); i++)
                {
                    double value = kerFunc1d(ngp.density(i,0),ngp.kernels(j-2));
                    expectation(j)+=value*ngp.density(i,1)/ngp.par;
                    variance(j)+=value*value*ngp.density(i,1)/ngp.par;
                }
                //if (expectation(j) > 5) 
                //    std::cout << "Anoamli" << std::endl;
                
                variance(j)-=expectation(j)*expectation(j);
            }
            //std::cout << "Expectation: " << expectation << std::endl;
        }
    }

    double MSNPGaussian::getNormDiff_feature(const Eigen::VectorXd& obs, const Eigen::VectorXd& x ,const MSNPGaussianParam1d& ngp)
    {

        double ret = 0;
        if (!regularizeMu_)
            ret += (obs(0)-x(0))*(obs(0)-x(0));
        else
            ret += (obs(0)-x(0)-l2alpha_*ngp.lambda1)*(obs(0)-x(0)-l2alpha_*ngp.lambda1); 
        /*if (!regularizeSigma_) ret += (obs(1)-x(1))*(obs(1)-x(1));
        else
            ret += (obs(1)-x(1)-l2alpha_*ngp.lambda2)*(obs(1)-x(1)-l2alpha_*ngp.lambda2);*/
        return std::sqrt(ret);
    }

    double MSNPGaussian::getNormDiff(const Eigen::VectorXd& obs, const Eigen::VectorXd& x)
    {

        double ret = 0;
        ret += (obs(0)-x(0))*(obs(0)-x(0));
        ret += (obs(1)-x(1))*(obs(1)-x(1));
        //std::cout << x << std::endl;
        for (int j=2; j < obs.size(); j++)
        {
            if (x(j) >= kerFuncMax_*p_lower_)
            //if (x(j) >= obs(j)*p_lower_)
                ;
            else ret+=std::pow(std::fabs(x(j)-kerFuncMax_*p_lower_),2);
            //else ret+=std::pow(std::fabs(x(j)-obs(j)*p_lower_),2);
        }
        return std::sqrt(ret);
    }
    
    double MSNPGaussian::getNormDiff_ball(const Eigen::VectorXd& obs, const Eigen::VectorXd& x)
    {

        double ret = 0;
        for (int j=2; j < obs.size(); j++)
        {
            if (regularizeExtra_)
            {
                //if (x(j) >= kerFuncMax_*p_lower_*obs(j)) ;
                //else ret+=std::pow(std::fabs(x(j)-kerFuncMax_*p_lower_*obs(j)),2);
                //if (x(j) >= obs(j)*p_lower_) ;
                // else ret+=std::pow(std::fabs(x(j)-obs(j)*p_lower_),2);
                if (fabs(x(j)-obs(j)) < membershipTol_) ;
                else ret+=std::pow(std::fabs(std::fabs(x(j)-obs(j))-membershipTol_),2);
            }
            //if (ret > 10)
            //{
            //    std::cout << "LOOKDFJSKF" << x(j) << std::endl;
            //}
            
            if (!regularizeExtra_)
                ret+=std::pow(std::fabs(x(j)-obs(j)),2);
            
        }
        return std::sqrt(ret);
    }

    double MSNPGaussian::calcKernels1d(double x, MSNPGaussianParam1d param)
    {
        double weight = 0;
        for (int i=0;i<param.kernels.size(); i++)
        {
            double y=param.kernels(i);
            weight+=param.lambdas(i)*kerFunc1d(x,y);
        }
        //return weight+param.mu*param.mu/2/param.sigma/param.sigma+std::log(std::fabs(param.sigma))
        return weight;
    }

    double MSNPGaussian::kerFunc1d(double x, double y)
    {
        if (kerType_ == uniform)
        {
            //step kernel
            if (std::fabs(y-x)/epsilon_ <= 1) return 0.5/epsilon_;
            else return 0;
            //smooth kernel
            //return 1.0/(1.0+std::exp(10*(std::fabs(y-x)-epsilon_/2)))*kerScale_;
        }
        else if (kerType_ == gaussian)
        {
            //return 1/std::sqrt(2*PI)*std::exp(-0.5*(x-y)*(x-y)/epsilon_/epsilon_)*kerScale_;
            return 1/std::sqrt(2*PI)*std::exp(-0.5*(x-y)*(x-y)/epsilon_/epsilon_)/epsilon_;
        }
        else 
        {
            return 0;
        }
    }

//     int SPGaussian::calcMaxPdf1d(double x, std::vector<SPGaussianParam1d>& params)
//     {
//         std::vector<double> scores(params.size());
//         for (unsigned int i=0; i<params.size(); i++)
//         {
//             boost::math::normal_distribution<double> normal_param(params[i].mu,params[i].sigma);
//             scores[i]=boost::math::pdf(normal_param, x)*std::exp(params[i].lambda*calcKernels(x,params[i]))/params[i].par;
//         }
//         int res = 0;
//         for (unsigned int i=0; i<scores.size(); i++)
//         {
//             if (scores[i]>scores[res]) res = i;
//         }
//         return res;
//     }

    double MSNPGaussian::MSNPGaussianPdf(double x, const MSNPGaussianParam1d& param)
    {
        //boost::math::normal_distribution<double> normal_param(param.mu,param.sigma);
        //return boost::math::pdf(normal_param, x)*std::exp(param.lambda*calcKernels1d(x,param))/param.par;
        double denom = 0;
        denom += param.lambda1*x;
        denom += param.lambda2*x*x;
        for (int i=0; i<param.lambdas.size();i++)
            denom+=param.lambdas(i)*kerFunc1d(x,param.kernels(i));
        return std::exp(denom)/param.par;
    }
}
