#ifndef __MSNPGaussian_h__
#define __MSNPGaussian_h__

#include <Eigen/Dense>
#include <string>
#include <vector>
#include <iostream>
#include "NPGaussian.hh"

namespace by{
    //const double PI = 3.1415926;
    class MSNPGaussian{
    public:
        typedef struct{
            double mu;
            double sigma;
            Eigen::MatrixX2d intervals;
            Eigen::VectorXd kernels;
            Eigen::VectorXd lambdas;
            double lambda;
            double lambda1;
            double lambda2;
            double par;
            Eigen::MatrixX2d density;
        } MSNPGaussianParam1d;
        typedef enum{
            uniform=0,
            gaussian,
            laplace
        } MSNPGaussianKerType;
        typedef enum{
            MonteCarlo,
            Quadrito
        }MSNPGaussianEst;
        //typedef struct{
        //    Eigen::VectorXd mu;
        //    Eigen::MatrixXd sigma;
        //} SPGaussianParamNd;
        MSNPGaussian();
        MSNPGaussian(int nc, int seed);
        void init(int nc, double p_lower_scale, double np_portion, double epsilon, int MC_NUM, std::string kerType,double gdiffthres, double l2alpha);
        void setVerbose(){verbose_=true;};
        void setPrior(double m1, double m2){prior1m_=m1;prior2m_=m2;};
        
        //std::vector<int> classify(const Eigen::MatrixXd& x_train, const std::vector<int>& y_train, const Eigen::MatrixXd& x_test);
        //NPGaussianParam1d getModel1d(const Eigen::MatrixXd& x);
        //int calcMaxPdf1d(double x, std::vector<NPGaussianParam1d>& params);
        //double NPGaussianPdf(double x, const NPGaussianParam1d& param);
        //GaussianParamNd getModelNd(const Eigen::MatrixXd& x);

        MSNPGaussianParam1d getModel1d(const Eigen::MatrixXd& x);
        double MSNPGaussianPdf(double x, const MSNPGaussianParam1d& param);

    private:
        void reCalcPartition(MSNPGaussianParam1d& param);
        void reCalcPartition_T(MSNPGaussianParam1d& param);
        void findKernels1d(const Eigen::MatrixXd& x, double portion, double epsilon, MSNPGaussianParam1d& ngp);
        void findDensity1d(MSNPGaussianParam1d& ngp);
        double solveForLambda(MSNPGaussianParam1d& ngp, int i,const Eigen::VectorXd& obs);
        double solveForVariance(MSNPGaussianParam1d& ngp,double var);
        void findObs1d(Eigen::VectorXd& obs, const Eigen::MatrixXd& x, const MSNPGaussianParam1d& ngp);
        double calcKernels1d(double x, MSNPGaussianParam1d param);
        double kerFunc1d(double x, double y);
        void pKernels1d(MSNPGaussianParam1d& ngp, Eigen::VectorXd& expectation, Eigen::VectorXd& variance);
        double getNormDiff(const Eigen::VectorXd& obs, const Eigen::VectorXd& x);
        double getNormDiff_feature(const Eigen::VectorXd& obs, const Eigen::VectorXd& x, const MSNPGaussianParam1d& ngp);
        double getNormDiff_ball(const Eigen::VectorXd& obs, const Eigen::VectorXd& x);
        double getDeltaV(double delta, const Eigen::VectorXd& density, const Eigen::VectorXd& kweights)
        {
            Eigen::VectorXd edeltak(kweights.size());
            for (int i=0; i<edeltak.size(); i++) 
            {
                edeltak(i) = std::exp(delta*kweights(i));
            }
            edeltak=edeltak.cwiseProduct(density);
            //std::cout << kweights.sum();
            return edeltak.dot(kweights)/edeltak.sum();// /(kweights.sum()/(epsilon_/0.05));
        }
        double Aeita(const MSNPGaussianParam1d& param)
        {
            return param.mu*param.mu/2/param.sigma/param.sigma+std::log(std::fabs(param.sigma));
        }
        //double pKernels1d(MSNPGaussianParam1d& sgp);
        bool verbose_;
        int nc_;
        double p_lower_scale_;
        double p_lower_;
        double np_portion_;
        double epsilon_;
        int seed_;
        MSNPGaussianKerType kerType_;
        int MC_NUM_;
        double gdiffthres_;
        double steplimit_;
        double kerFuncMax_;
        MSNPGaussianEst estMethod_;
        double kerScale_;
        double sep_;
        int start_;
        int end_;
        bool regularizeMu_;
        bool regularizeSigma_;
        bool regularizeExtra_;
        double membershipTol_;
        double l2alpha_;
        double prior1m_;
        double prior2m_;
    };
}

#endif
