#ifndef __WatsonNadaraya_h__
#define __WatsonNadaraya_h__

#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <boost/shared_ptr.hpp>
#include <string>

using namespace boost::numeric::ublas;

namespace by{
    class WatsonNadaraya{
    public:
        WatsonNadaraya();
        WatsonNadaraya(int nc, const std::string& kt=std::string("knn"));
        void init(int nc, const std::string& kt=std::string("knn"));
        void setVerbose(){verbose_=true;};
        vector<int> classify(const matrix<double>& x_train, const vector<int>& y_train, const matrix<double>& x_test);
        void setKernelWidth(double w){kernel_width_=w;};
        typedef enum{
            KNN,
            GAUSSIAN,
            LAPLACIAN,
            EPACHEV
        }kernel_type;
        typedef boost::shared_ptr<matrix<double> > matrixdPtr;
        typedef boost::shared_ptr<const matrix<double> > const_matrixdPtr;
        vector<double> wnkernelweights(
            const std::vector<matrixdPtr> x_train_split,
            const matrix_row<const matrix<double> >& xtr );
        double kernelweight1d(
            const vector<double>& x_train,
            const double& x );
        double kernel1d(
            const double& x,
            const double& y);
        double kernel(
            const matrix_row<const matrix<double> >& x,
            const matrix_row<const matrix<double> >& y);
    private:
        bool verbose_;
        kernel_type kernel_;
        int nc_;
        double kernel_width_;
    };
}

#endif
