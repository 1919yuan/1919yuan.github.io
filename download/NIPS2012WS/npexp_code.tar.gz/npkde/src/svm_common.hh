#ifndef __SVM_COMMON_h__
#define __SVM_COMMON_h__

#include <vector>
#include <string>
#include <cctype>

namespace by{

    class SvmDoc{
    public:
        typedef struct word {
            long    wnum;	               /* word number */
            float   weight;               /* word weight */
        }WORD;
        typedef struct svector {
            std::vector<WORD> words;
        }SVECTOR;
        /*long    docnum;              /* Document ID. This has to be the position of 
                                      the document in the training set array. */
        /*long    queryid;             /* for learning rankings, constraints are 
				                      generated for documents with the same 
				                      queryID. */
        std::vector<SVECTOR> fvec;
        std::vector<int> label;
        long int totwords;
        long int totdoc;
        int scale;

        SvmDoc():totwords(0),totdoc(0),verbosity_(0){};
        SvmDoc(const std::string svmfile,int s = 100, int v=0);

    private:
        int verbosity_;
        void nol_ll_(const std::string& file, long int& maxdoc, long int& maxwords, long int& ll);

    };

}
#endif
