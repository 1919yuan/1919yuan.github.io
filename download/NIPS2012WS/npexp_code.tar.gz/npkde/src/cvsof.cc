#include "Normal.hh"
#include "StudentT.hh"
#include "Gaussian.hh"
#include "SPGaussian.hh"
#include "NPGaussian.hh"
#include "MSNPGaussian.hh"
#include "WatsonNadaraya.hh"
#include "GMM.hh"
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <Eigen/Dense>
#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/normal.hpp>
#include "time.h"

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include "getopt.h"
#else 
#include <unistd.h>
#endif 

//static double kernelcv[]={0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6};
//static int kcv_N=13;

static double kernelcv[]={0.05,0.1,0.15,0.2,0.4,0.6,0.8,1,1.2,1.4};
static int kcv_N=10;

static int onlykde_flag;
static int logdelta_flag;
static int fixdelta_flag;
static int msnp_flag;
static int cv_flag;
static int verbose_flag;
static int bimodel_flag;
static int normal_flag;
static int opdata_flag;
static char help_msg[] = "Usage: gof [-h] [--verbose]\n\
  -h [ --help ]: print this help.\n\
  -f [ --visfile ] filename: set the file name to store visualization data generated for visualization.\n\
  -p [ --lower_p ] lower_p: set the lower bound for spgaussian.\n\
  -n [ --num ] number: number of data points to generate.\n\
  -k [ --kwidth ] kernel: width of kernel.\n\
  -e [ --kernel ] kernel_type: kernel type.\n\
  -l [ --tolerance ] tol: tolerance for optimization in NPGaussian. \n\
  -a [ --l2alpha ] alpha: alpha for l2 regularization on mean parameters. \n\
  -d [ --degree ] deg: degree for t distribution. \n\
  -s [ --sigma ] sigma: sigma for normal distribution. \n\
  -r [ --seed ] seed: random seed. \n\
  [ --verbose ]: set verbose flag\n\
  [ --bimodel ]: what kind of t-distribution model should I generate.\n\
  [ --normal ]: whether use normal or t for unimodel experiment.\n\
  [ --cv ]: use cross validation on kernel width. \n\
  [ --opdata ]: output training and testing data. \n\
  [ --msnp ]: using prior mu and sigma info. \n\
  [ --fixdelta ]: fix delta, not 1/sqrt(n). \n\
  [ --logdelta ]: let delta grow low. \n\
Example: gof -f\"wsg.den\"\n\
";

int main(int argc, char** argv)
{
    int c;
    static struct option long_options[]=
    {
        {"verbose", no_argument, &verbose_flag, 1},
        {"bimodel", no_argument, &bimodel_flag, 1},
        {"normal", no_argument, &normal_flag, 1},
        {"onlykde", no_argument, &onlykde_flag, 1},
        {"cv", no_argument, &cv_flag, 1},
        {"opdata", no_argument, &opdata_flag, 1},
        {"msnp", no_argument, &msnp_flag, 1},
        {"fixdelta", no_argument, &fixdelta_flag, 1},
        {"logdelta", no_argument, &logdelta_flag, 1},
        {"kernel", required_argument, 0, 'e'},
        {"kernelp", required_argument, 0, 'p'},
        {"tolerance", required_argument, 0, 'l'},
        {"l2alpha", required_argument, 0, 'a'},
        {"kwidth", required_argument, 0, 'k'},
        {"num", required_argument, 0, 'n'},
        {"help", no_argument, 0, 'h'},
        {"degree", required_argument, 0, 'd'},
        {"sigma", required_argument, 0, 's'},
        {"seed", required_argument, 0, 'r'},
        {0,0,0,0}
    };

    int option_index=0;
    int d=1;
    int n=10000;
    int n_crossvalid=(int)(1.1*n);
    int sep=1000;
    int deg = 6;
    double mu1 = -3;
    double mu2 = 3;
    double sigma = 1;
    double kernelp = 0.01;
    double tol = 0.01;
    double l2alpha = 10;
    std::string kernel("gaussian");
    double kernelwidth=1;
    int randomseed=34234;
    int randomseed1=44234;

    int errflg=0;
    while ((c = getopt_long(argc, argv, "hf:p:n:k:e:l:a:d:s:r:",long_options,&option_index)) != -1)
    {
        switch (c) {
        case 0:
            break;
        case 'p':
            kernelp = std::atof(optarg);
            break;
        case 'd':
            deg = std::atoi(optarg);
            break;
        case 's':
            sigma = std::atof(optarg);
            break;
        case 'n':
            n = std::atoi(optarg);
            n_crossvalid = (int)(1.1*n);
            break;
        case 'r':
            randomseed = std::atoi(optarg);
            //randomseed1 = 10000+randomseed;
            break;
        case 'l':
            tol = std::atof(optarg);
            break;
        case 'a':
            l2alpha = std::atof(optarg);
            break;
        case 'k':
            kernelwidth = std::atof(optarg);
            break;
        case 'e':
            kernel=std::string(optarg);
            break;
        case '?':
            errflg++;
            break;
        default:
            errflg++;
            break;
        }
    }
    if (errflg || argc == 1) {
        std::cout << help_msg << std::endl;
        exit (0);
    }

    by::StudentT tgen = by::StudentT(randomseed);
    by::Normal ngen = by::Normal(randomseed);
    std::srand(randomseed);
    Eigen::MatrixXd data(n,1);
    Eigen::MatrixXd data_extra(n_crossvalid-n,1);
    Eigen::MatrixXd data_pool(n_crossvalid,1);
    if (!fixdelta_flag && !logdelta_flag)
        kernelp = kernelp/std::sqrt(n);
    else if (logdelta_flag )
        kernelp = kernelp/std::log(n);

    if (!bimodel_flag) 
    {
        if (!normal_flag)
        {
            data_pool=tgen.TDistRandom(0,deg,n_crossvalid,1);
            for (int i=0; i<n; i++)
                data(i,0)=data_pool(i,0);
            for (int i=n; i<n_crossvalid; i++)
                data_extra(i-n,0)=data_pool(i,0);
        }
        else
        {
            data_pool=ngen.NormalRandom(0,sigma,n,1);
            for (int i=0; i<n; i++)
                data(i,0)=data_pool(i,0);
            for (int i=n; i<n_crossvalid; i++)
                data_extra(i-n,0)=data_pool(i,0);
        }
    }
    else
    {
        for (int i=0; i<n_crossvalid; i++)
        {
            if (std::rand()/(1.0+RAND_MAX) < 0.5)
            {
                Eigen::MatrixXd tmp =ngen.NormalRandom(mu1,sigma,1,1);
                data_pool(i,0)=tmp(0,0);
            }
            else
            {
                Eigen::MatrixXd tmp =ngen.NormalRandom(mu2,sigma,1,1);
                data_pool(i,0)=tmp(0,0);
            }
        }
        for (int i=0; i<n; i++)
            data(i,0)=data_pool(i,0);
        for (int i=n; i<n_crossvalid; i++)
            data_extra(i-n,0)=data_pool(i,0);
    }
    Eigen::MatrixXd density(sep,6);
    density.setZero();
    if (verbose_flag)
        std::cout << data.rows() << " " <<data.cols()<<std::endl;
    boost::numeric::ublas::vector<double> data_boostcopy(n);
    for (int i=0; i<n; i++) data_boostcopy(i)=data(i,0);

    double start=-10;
    double end=10;

    int n_test=100000;
    by::StudentT tgen1=by::StudentT(randomseed1);
    by::Normal ngen1 = by::Normal(randomseed1);
    std::srand(randomseed1);
    Eigen::MatrixXd data_test(n_test,1);

    if (!bimodel_flag)
    {
        if (!normal_flag)
            data_test=tgen1.TDistRandom(0,deg,n_test,1);
        else
            data_test=ngen1.NormalRandom(0,sigma,n_test,1);
    }
    else
    {
        for (int i=0; i<n_test; i++)
        {
            if (std::rand()/(1.0+RAND_MAX) < 0.5)
            {
                Eigen::MatrixXd tmp =ngen1.NormalRandom(mu1,sigma,1,1);
                data_test(i,0)=tmp(0,0);
            }
            else
            {
                Eigen::MatrixXd tmp =ngen1.NormalRandom(mu2,sigma,1,1);
                data_test(i,0)=tmp(0,0);
            }
        }
    }

    if (opdata_flag)
    {
        std::stringstream ss;
        ss << "opdata_n" << n << "_r" << randomseed;
        if (bimodel_flag)
            ss << "_bexp.csv";
        else if (normal_flag) 
            ss << "_rexp.csv";
        else 
            ss << "_texp.csv";
        std::string optrainfile;
        ss >> optrainfile;    
        std::ofstream opdata_train(optrainfile.c_str());
        for (int i=0; i<data.rows(); i++)
        {
            for (int j=0; j<data.cols()-1; j++)
            {
                opdata_train << data(i,j) << ",";
            }
            opdata_train << data(i,data.cols()-1) << std::endl;
        }
        std::stringstream ss1;
        ss1 << "opdata_testn" << n << "_r" << randomseed;
        if (bimodel_flag)
            ss1 << "_bexp.csv";
        else if (normal_flag) 
            ss1 << "_rexp.csv";
        else 
            ss1 << "_texp.csv";
        std::string optestfile;
        ss1 >> optestfile;    
        std::ofstream opdata_test(optestfile.c_str());
        for (int i=0; i<data_test.rows(); i++)
        {
            for (int j=0; j<data_test.cols()-1; j++)
            {
                opdata_test << data_test(i,j) << ",";
            }
            opdata_test << data_test(i,data_test.cols()-1) << std::endl;
        }
        exit(0);
    }

    int bestkcv_KDE = 0;
    double bestlo_KDE = -1000;
    int bestkcv_NP = 0;
    double bestlo_NP = -1000;
    int bestkcv_MSNP = 0;
    double bestlo_MSNP = -1000;
    if (cv_flag)
    {
    for (int kcv_i=0; kcv_i<kcv_N; kcv_i++)
    {
        double loglik[5];
        memset(loglik, 0, 5*sizeof(double));
        for (int kcv_j=0; kcv_j<11; kcv_j++)
        {
            std::cout << "[kcv:" << kcv_i << "; fold:" << kcv_j << "]" << std::endl;
            int cutbegin = (int) (0.1*n*kcv_j);
            int cutend =(int) (0.1*n*(kcv_j+1));
            for (int i=0; i<cutbegin; i++)
                data(i,0)=data_pool(i,0);
            for (int i=cutbegin; i < cutend; i++)
                data_extra(i-cutbegin,0)=data_pool(i,0);
            for (int i=cutend; i< n_crossvalid; i++)
                data(i-(cutend-cutbegin),0)=data_pool(i,0);

            for (int i=0; i<n; i++) data_boostcopy(i)=data(i,0);

            //by::Gaussian gaussianclassifier;
            by::WatsonNadaraya wnclassifier(2,kernel);
            wnclassifier.setKernelWidth(kernelcv[kcv_i]);
            by::NPGaussian npGaussianModel;
            by::MSNPGaussian msnpGaussianModel;
            by::MSNPGaussian::MSNPGaussianParam1d msnp_param;
            by::NPGaussian::NPGaussianParam1d np_param;
            npGaussianModel.init(1,kernelp,1,kernelcv[kcv_i],100000,kernel,tol,l2alpha);
            if (bimodel_flag && msnp_flag)
            {
                msnpGaussianModel.init(1,kernelp,1,kernelcv[kcv_i],100000,kernel,tol,l2alpha);
                msnpGaussianModel.setPrior((mu1+mu2)/2,sigma*sigma+mu1*mu1/2+mu2*mu2/2);
                msnp_param=msnpGaussianModel.getModel1d(data);
            }

            //by::Gaussian::GaussianParam1d gp_param = gaussianclassifier.getModel1d(data);
            if (!onlykde_flag)
                np_param = npGaussianModel.getModel1d(data);
            //output the loglikelihood for each estimation
            for (int i=0;i<data_extra.rows();i++)
            {
                double tmppp=wnclassifier.kernelweight1d(data_boostcopy,data_extra(i,0));
                if (tmppp==0)
                    loglik[1]+=-308;
                else
                    loglik[1]+=std::log(tmppp);

                if (!onlykde_flag)
                    loglik[4]+=std::log(npGaussianModel.NPGaussianPdf(data_extra(i,0),np_param));
                if (bimodel_flag && msnp_flag)
                    loglik[3]+=std::log(msnpGaussianModel.MSNPGaussianPdf(data_extra(i,0),msnp_param));
            }
        }
        int tmpn_test=(n_crossvalid-n)*11;
        if (loglik[1]/tmpn_test > bestlo_KDE) {bestkcv_KDE=kcv_i;bestlo_KDE=loglik[1]/tmpn_test;}
        if (loglik[4]/tmpn_test > bestlo_NP) {bestkcv_NP=kcv_i;bestlo_NP=loglik[4]/tmpn_test;}
        if (bimodel_flag && msnp_flag && loglik[3]/tmpn_test > bestlo_MSNP) {bestkcv_MSNP=kcv_i;bestlo_MSNP=loglik[3]/tmpn_test;}
    }
    }

    if (cv_flag)
    {
        //std::srand(randomseed1+10000);
        //int* p= new int [n_crossvalid];
        //for (int i=0; i<n_crossvalid; ++i)
        //{
        //    int j= std::rand() % (i+1);
        //    p[i]=p[j];
        //    p[j]=i;
        //}
        for (int i=0; i<n; ++i)
        {
            //data(i,0)=data_pool(p[i],0);
            data(i,0)=data_pool(i,0);
            data_boostcopy(i)=data(i,0);
        }
        //delete[] p;
    }

    by::Gaussian gaussianclassifier;
    by::WatsonNadaraya wnclassifier(2,kernel);
    if (cv_flag)
        wnclassifier.setKernelWidth(kernelcv[bestkcv_KDE]);
    else
        wnclassifier.setKernelWidth(kernelwidth);
    by::NPGaussian npGaussianModel;
    by::MSNPGaussian msnpGaussianModel;
    by::MSNPGaussian::MSNPGaussianParam1d msnp_param;
    by::NPGaussian::NPGaussianParam1d np_param;
    by::Gaussian::GaussianParam1d gp_param;

    if (cv_flag)
    {
        npGaussianModel.init(1,kernelp,1,kernelcv[bestkcv_NP],100000,kernel,tol,l2alpha);
        if (bimodel_flag && msnp_flag)
        {
            msnpGaussianModel.init(1,kernelp,1,kernelcv[bestkcv_MSNP],100000,kernel,tol,l2alpha);
            msnpGaussianModel.setPrior((mu1+mu2)/2,sigma*sigma+mu1*mu1/2+mu2*mu2/2);
            msnp_param=msnpGaussianModel.getModel1d(data);
        }
    }
    else 
    {
        npGaussianModel.init(1,kernelp,1,kernelwidth,100000,kernel,tol,l2alpha);
        if (bimodel_flag && msnp_flag)
        {
            msnpGaussianModel.init(1,kernelp,1,kernelwidth,100000,kernel,tol,l2alpha);
            msnpGaussianModel.setPrior((mu1+mu2)/2,sigma*sigma+mu1*mu1/2+mu2*mu2/2);
            msnp_param=msnpGaussianModel.getModel1d(data);
        }
        else if (normal_flag && msnp_flag)
        {
            msnpGaussianModel.init(1,kernelp,1,kernelwidth,100000,kernel,tol,l2alpha);
            msnpGaussianModel.setPrior(0,sigma);
            msnp_param=msnpGaussianModel.getModel1d(data);
        }
        else if (msnp_flag)
        {
            msnpGaussianModel.init(1,kernelp,1,kernelwidth,100000,kernel,tol,l2alpha);
            msnpGaussianModel.setPrior(0,(double)deg/((double)deg-2));
            msnp_param=msnpGaussianModel.getModel1d(data);
        }
    } 
    if (!onlykde_flag)
    {
        gp_param = gaussianclassifier.getModel1d(data);
        np_param = npGaussianModel.getModel1d(data);
    }
    if (verbose_flag)
        npGaussianModel.setVerbose();
    //GMM gmmmodel(1,2);
    //if (bimodel_flag)
    //{
        //gmmmodel.insertData(data);
        //gmmmodel.iterateGMM(10);
    //}

    boost::math::students_t_distribution<double> tdist(deg);
    boost::math::normal_distribution<double> ndist(0,sigma);
    boost::math::normal_distribution<double> ndist1(mu1,sigma);
    boost::math::normal_distribution<double> ndist2(mu2,sigma);

    for (int i=0;i<sep;i++)
    {
        density(i,0)=start+(end-start)/sep*i+(end-start)/sep/2;
        if (!bimodel_flag)
        {
            if (!normal_flag)
                density(i,1)=boost::math::pdf(tdist,density(i,0));
            else
                density(i,1)=boost::math::pdf(ndist,density(i,0));
        }
        else
        {
            density(i,1)=boost::math::pdf(ndist1,density(i,0))/2+boost::math::pdf(ndist2,density(i,0))/2;
        }
        density(i,2)=wnclassifier.kernelweight1d(data_boostcopy,density(i,0));
        if (!onlykde_flag) density(i,3)=gaussianclassifier.calcPdf1d(density(i,0),gp_param);
        if (msnp_flag)
        {
            density(i,4)=msnpGaussianModel.MSNPGaussianPdf(density(i,0),msnp_param);
            //float tmpd = density(i,0);
            //density(i,4)=gmmmodel.getLikelihood(&tmpd);
        }
        if (!onlykde_flag) density(i,5)=npGaussianModel.NPGaussianPdf(density(i,0),np_param);
        //std::cout << np_param.lambdas << std::endl;
    }
    std::stringstream ss;
    ss << "wsg_n" << n << "_r" << randomseed;
    if (bimodel_flag)
        ss << "_bexp.den";
    else if (normal_flag) 
        ss << "_rexp.den";
    else 
        ss << "_texp.den";

    std::string visfile;
    ss >> visfile;
    std::ofstream outDensity(visfile.c_str());
    for (int i=0;i<sep;i++) 
    {
        for (int j=0; j<6; j++) outDensity << density(i,j) << " ";
        outDensity << std::endl;
    }
    //output the sampled points

    std::stringstream ss1;
    ss1 << "kernels_n" << n << "_r" << randomseed;
    if (bimodel_flag)
        ss1 << "_bexp.den";
    else if (normal_flag) 
        ss1 << "_rexp.den";
    else 
        ss1 << "_texp.den";
    std::string kernelsfile;
    ss1 >> kernelsfile;    

    std::ofstream outKernels(kernelsfile.c_str());
    if (verbose_flag) std::cout << np_param.lambdas << std::endl;
    for (int i=0;i<np_param.kernels.rows();i++) 
    {
        outKernels << np_param.kernels(i) << std::endl;
    }
    
    //output the loglikelihood for each estimation
    double loglik[5];
    memset(loglik, 0, 5*sizeof(double));
    for (int i=0;i<data_test.rows();i++)
    {
        if (!bimodel_flag)
        {
            if (!normal_flag)
                loglik[0]+=std::log(boost::math::pdf(tdist,data_test(i,0)));
            else
                loglik[0]+=std::log(boost::math::pdf(ndist,data_test(i,0)));
        }
        else
            loglik[0]+=(std::log(boost::math::pdf(ndist1,data_test(i,0))/2+boost::math::pdf(ndist2,data_test(i,0))/2));
        double tmppp=wnclassifier.kernelweight1d(data_boostcopy,data_test(i,0));
        if (tmppp==0)
            loglik[1]+=-308;
        else 
            loglik[1]+=std::log(tmppp);
        if (!onlykde_flag) loglik[2]+=std::log(gaussianclassifier.calcPdf1d(data_test(i,0),gp_param));
        if (msnp_flag)
        {
            //float tmpd = data_test(i,0);
            //loglik[3]+=std::log(gmmmodel.getLikelihood(&tmpd));
            loglik[3]+=std::log(msnpGaussianModel.MSNPGaussianPdf(data_test(i,0),msnp_param));
        }
        if (!onlykde_flag) loglik[4]+=std::log(npGaussianModel.NPGaussianPdf(data_test(i,0),np_param));
        //std::cout << np_param.lambdas << std::endl;
    }
    
    std::stringstream ss2;
    ss2 << "loglik_n" << n << "_r" << randomseed;
    if (bimodel_flag)
        ss2 << "_bexp.den";
    else if (normal_flag) 
        ss2 << "_rexp.den";
    else 
        ss2 << "_texp.den";
    std::string logliksfile;
    ss2 >> logliksfile;    

    std::ofstream outLoglik(logliksfile.c_str());
    for (int i=0;i<5;i++) 
    {
        outLoglik << loglik[i] << std::endl;
    }
    int nnz=0;
    for (int i=0; i<np_param.lambdas.size();i++)
        if (np_param.lambdas(i)!=0) nnz++;
    outLoglik << nnz << std::endl;
    if (msnp_flag)
    {
        nnz=0;
        for (int i=0; i<msnp_param.lambdas.size();i++)
            if (msnp_param.lambdas(i)!=0) nnz++;
        outLoglik << nnz << std::endl;
    }
    if (cv_flag)
    {
        outLoglik << kernelcv[bestkcv_NP] << std::endl;
        outLoglik << kernelcv[bestkcv_KDE] << std::endl;
        outLoglik << kernelcv[bestkcv_MSNP] << std::endl;
        std::cout << "Bestkcv_NP:" << kernelcv[bestkcv_NP] << " ; Bestkcv_KDE:" << kernelcv[bestkcv_KDE] <<" ; Bestkcv_MSNP:" << kernelcv[bestkcv_MSNP] << std::endl;
    }
    //gmmmodel.printModels();
    std::cout << std::endl;


}
