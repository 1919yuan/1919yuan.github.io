#include "StudentT.hh"
#include <iostream>
#include <fstream>
#include <vector>
#include <Eigen/Dense>

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include "getopt.h"
#else 
#include <unistd.h>
#endif 

static int verbose_flag;
static int output_flag;

static char help_msg[] = 
"Usage: gen_tdist [-d df] [-h] [--verbose] [-o outputfile] [-m posnum] [-n negnum] [-x c1] [-y c2]\n\
  -h [ --help ]: print this help.\n\
  -d [ --df ] dof: set the degree of freedom for t distribution.\n\
  -o [ --output ] outputfile: save the output in libsvm format.\n\
  -m [ --positive ] posnum: set the number of samples to generate for positive class.\n\
  -n [ --negative ] negnum: set the number of samples to generate for negative class.\n\
  -x [ --posmean ] c1: set mean of positive class.\n\
  -y [ --negmean ] c2: set mean of negative class.\n\
  -s [ --seed ] seed: set the seed for random number generator.\n\
  [ --verbose ]: verbose flag.\n\
";

int main(int argc, char** argv)
{
    int c;
    std::string oFile;
    int dof=3;
    int n1=10,n2=10;
    double c1=-3, c2=3;
    int seed = 23423;
    static struct option long_options[]=
    {
        {"verbose", no_argument, &verbose_flag, 1},
        {"positive", required_argument, 0, 'm'},
        {"negative", required_argument, 0, 'n'},
        {"posmean", required_argument, 0, 'x'},
        {"negmean", required_argument, 0, 'y'},
        {"output", required_argument, 0, 'o'},
        {"df", required_argument, 0, 'd'},
        {"seed", required_argument, 0, 's'},
        {0,0,0,0}
    };

    int option_index=0;
    
    int errflg=0;
    while ((c = getopt_long(argc, argv, "s:d:m:n:x:y:ho:",long_options,&option_index)) != -1)
    {
        switch (c) {
        case 0:
            break;
        case 'd':
            dof=std::atoi(optarg);
            break;
        case 'm':
            n1=std::atoi(optarg);
            break;
        case 'n':
            n2=std::atoi(optarg);
            break;
        case 'x':
            c1=std::atof(optarg);
            break;
        case 'y':
            c2=std::atof(optarg);
            break;
        case 's':
            seed = std::atoi(optarg);
            break;
        case 'o':
            output_flag = 1;
            oFile=std::string(optarg);
            break;
        case '?':
            errflg++;
            break;
        default:
            errflg++;
            break;
        }
        
    }
    /*ConfigFile config;
    try
    {
        config=ConfigFile(configfile.c_str());
    }
    catch (ConfigFile::file_not_found)
    {
        errflg++;
        std::cerr << configfile << " not found!" << std::endl;
    }*/
    if (errflg){// || argc == 1) {
        std::cout << help_msg << std::endl;
        exit (0);
    }
    by::StudentT tdist(seed);
    Eigen::MatrixXd m1 = tdist.TDistRandom(c1,dof,n1,1);
    Eigen::MatrixXd m2 = tdist.TDistRandom(c2,dof,n2,1);
    if (output_flag)
    {
        std::ofstream outfile(oFile.c_str());
        for (int i=0; i<n1; i++) outfile << "+1 1:" << m1(i,0) << std::endl;
        for (int i=0; i<n2; i++) outfile << "-1 1:" << m2(i,0) << std::endl;
    }
    else
    {
        for (int i=0; i<n1; i++) std::cout << "+1 1:" << m1(i,0) << std::endl;
        for (int i=0; i<n2; i++) std::cout << "-1 1:" << m2(i,0) << std::endl;
    }
}
