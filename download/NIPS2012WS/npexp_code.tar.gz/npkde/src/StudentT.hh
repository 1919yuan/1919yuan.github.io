#ifndef __StudentT_h__
#define __StudentT_h__

#include <boost/random/student_t_distribution.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/generator_iterator.hpp>
#include <boost/random.hpp>
#include <Eigen/Dense>

namespace by{
    class StudentT{
    private:
        typedef boost::mt19937 base_generator_type;
        typedef boost::mt19937::result_type base_generator_result_type;
    public:
        StudentT(base_generator_type::result_type seed);
        Eigen::MatrixXd TDistRandom(double mu, int deg,  
                                    int nrow, int ncol);
        Eigen::MatrixXd MultTDistRandom(const Eigen::VectorXd& mu,
                                         const Eigen::MatrixXd& sigma,
                                         const int& deg,
                                         const int& d,
                                         const int& n);
                                        
    private:
        typedef boost::variate_generator<base_generator_type&, 
            boost::random::student_t_distribution<> > gen_type;
        base_generator_type generator_;
        base_generator_result_type seed_;
    };
}

#endif
