#ifndef __NPGaussian_h__
#define __NPGaussian_h__

#include <Eigen/Dense>
#include <string>
#include <vector>
#include <iostream>

namespace by{
    const double PI = 3.1415926;
    class NPGaussian{
    public:
        typedef struct{
            double mu;
            double sigma;
            Eigen::MatrixX2d intervals;
            Eigen::VectorXd kernels;
            Eigen::VectorXd lambdas;
            double lambda;
            double lambda1;
            double lambda2;
            double par;
            Eigen::MatrixX2d density;
        } NPGaussianParam1d;
        typedef enum{
            uniform=0,
            gaussian,
            laplace
        } NPGaussianKerType;
        typedef enum{
            MonteCarlo,
            Quadrito
        }NPGaussianEst;
        //typedef struct{
        //    Eigen::VectorXd mu;
        //    Eigen::MatrixXd sigma;
        //} SPGaussianParamNd;
        NPGaussian();
        NPGaussian(int nc, int seed);
        void init(int nc, double p_lower_scale, double np_portion, double epsilon, int MC_NUM, std::string kerType,double gdiffthres, double l2alpha);
        void setVerbose(){verbose_=true;};
        
        //std::vector<int> classify(const Eigen::MatrixXd& x_train, const std::vector<int>& y_train, const Eigen::MatrixXd& x_test);
        //NPGaussianParam1d getModel1d(const Eigen::MatrixXd& x);
        //int calcMaxPdf1d(double x, std::vector<NPGaussianParam1d>& params);
        //double NPGaussianPdf(double x, const NPGaussianParam1d& param);
        //GaussianParamNd getModelNd(const Eigen::MatrixXd& x);

        NPGaussianParam1d getModel1d(const Eigen::MatrixXd& x);
        double NPGaussianPdf(double x, const NPGaussianParam1d& param);

    private:
        void reCalcPartition(NPGaussianParam1d& param);
        void reCalcPartition_T(NPGaussianParam1d& param);
        void findKernels1d(const Eigen::MatrixXd& x, double portion, double epsilon, NPGaussianParam1d& ngp);
        void findDensity1d(NPGaussianParam1d& ngp);
        double solveForLambda(NPGaussianParam1d& ngp, int i,const Eigen::VectorXd& obs);
        double solveForVariance(NPGaussianParam1d& ngp,double var);
        void findObs1d(Eigen::VectorXd& obs, const Eigen::MatrixXd& x, const NPGaussianParam1d& ngp);
        double calcKernels1d(double x, NPGaussianParam1d param);
        double kerFunc1d(double x, double y);
        void pKernels1d(NPGaussianParam1d& ngp, Eigen::VectorXd& expectation, Eigen::VectorXd& variance);
        double getNormDiff(const Eigen::VectorXd& obs, const Eigen::VectorXd& x);
        double getNormDiff_feature(const Eigen::VectorXd& obs, const Eigen::VectorXd& x, const NPGaussianParam1d& ngp);
        double getNormDiff_ball(const Eigen::VectorXd& obs, const Eigen::VectorXd& x);
        double getDeltaV(double delta, const Eigen::VectorXd& density, const Eigen::VectorXd& kweights)
        {
            Eigen::VectorXd edeltak(kweights.size());
            for (int i=0; i<edeltak.size(); i++) 
            {
                edeltak(i) = std::exp(delta*kweights(i));
            }
            edeltak=edeltak.cwiseProduct(density);
            //std::cout << kweights.sum();
            return edeltak.dot(kweights)/edeltak.sum();// /(kweights.sum()/(epsilon_/0.05));
        }
        double Aeita(const NPGaussianParam1d& param)
        {
            return param.mu*param.mu/2/param.sigma/param.sigma+std::log(std::fabs(param.sigma));
        }
        //double pKernels1d(NPGaussianParam1d& sgp);
        bool verbose_;
        int nc_;
        double p_lower_scale_;
        double p_lower_;
        double np_portion_;
        double epsilon_;
        int seed_;
        NPGaussianKerType kerType_;
        int MC_NUM_;
        double gdiffthres_;
        double steplimit_;
        double kerFuncMax_;
        NPGaussianEst estMethod_;
        double kerScale_;
        double sep_;
        int start_;
        int end_;
        bool regularizeMu_;
        bool regularizeSigma_;
        bool regularizeExtra_;
        double membershipTol_;
        double l2alpha_;
    };
}

#endif
