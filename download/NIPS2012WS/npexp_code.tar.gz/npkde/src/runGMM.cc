#include <iostream>
#include <fstream>
#include <vector>
#include <Eigen/Dense>

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include "getopt.h"
#else 
#include <unistd.h>
#endif 

static int verbose_flag;
static int train_flag;
static int test_flag;

static char help_msg[] = 
"Usage: semp [-d TrainFileName] [-t TestFileName] [-p SavedTrainParamFile] [-s OutputTrainParamFile] [-v|-h] OA[-o OutputResultFile]\n\
  -h [ --help ]: print this help.\n\
  -d [ --train ] TrainFileName: set the training input file.\n\
  -t [ --test ] TestFileName: set the testing input file.\n\
  -p [ --rmodel ] SavedTrainParamFile: set the file to read in the trained model.\n\
  -s [ --smodel ] OutputTrainParamFile: set the output file to save the trained model.\n\
  -o [ --output ] OutputResultFile: set the output result file to write the output.\n\
  -v [ --verbose ]: verbose flag.\n\
";

int main(int argc, char** argv)
{
    int c;
    std::string trainFile;
    std::string testFile;
    std::string optimizer("lbfgs");
    std::string linesearch("secant");
    //std::string oFile;
    static struct option long_options[]=
    {
        {"verbose", no_argument, &verbose_flag, 1},
        {"train", required_argument, 0, 'd'},
        {"test", required_argument, 0, 't'},
        {"rmodel", required_argument, 0, 'p'},
        {"smodel", required_argument, 0, 's'},
        {"linesearch", required_argument, 0, 'l'},
        {"optimizer", required_argument, 0, 'o'},
        {0,0,0,0}
    };

    int option_index=0;
    
    int errflg=0;
    while ((c = getopt_long(argc, argv, "d:t:s:p:hl:o:",long_options,&option_index)) != -1)
    {
        switch (c) {
        case 0:
            break;
        case 'd':
            trainFile=std::string(optarg);
            train_flag=1;
            break;
        case 't':
            test_flag=1;
            testFile=std::string(optarg);
            break;
        case 'p':
            rmodel_flag=1;
            rmodelFile=std::string(optarg);
            break;
        case 's':
            smodel_flag=1;
            smodelFile=std::string(optarg);
            break;
        case 'o':
            optimizer=std::string(optarg);
            break;
        case 'l':
            linesearch=std::string(optarg);
            break;
        case '?':
            errflg++;
            break;
        default:
            errflg++;
            break;
        }
        
    }
    /*ConfigFile config;
    try
    {
        config=ConfigFile(configfile.c_str());
    }
    catch (ConfigFile::file_not_found)
    {
        errflg++;
        std::cerr << configfile << " not found!" << std::endl;
    }*/
    if (errflg || argc == 1) {
        std::cout << help_msg << std::endl;
        exit (0);
    }
    LogReg* pLogReg = NULL;
    if (train_flag)
    {
        SvmDoc sdoc(trainFile);
        pLogReg = new LogReg(sdoc.totwords+1,verbose_flag);
        if (!optimizer.compare("lbfgs"))
        {
            pLogReg->setOptType(LogReg::LBFGS);
        }
        else if (!optimizer.compare("gd"))
        {
            pLogReg->setOptType(LogReg::GD);
            if (!linesearch.compare("bisect"))
                pLogReg->setLineSearchType(LogReg::BISECT);
            else 
                pLogReg->setLineSearchType(LogReg::SECANT);
        }
        else //if (!optimizer.compare("cd"))
        {
            pLogReg->setOptType(LogReg::CD);
            if (!linesearch.compare("bisect"))
                pLogReg->setLineSearchType(LogReg::BISECT);
            else 
                pLogReg->setLineSearchType(LogReg::SECANT);
        }
        int logreg_status = pLogReg->train(sdoc);
        if (logreg_status != -1001 && logreg_status!=0 && logreg_status!=-998 && logreg_status!=-997) // failed linesearch
        {
            std::cerr << "[Warning]: Training failed, 1d line search didn't work. Reason " << logreg_status << std::endl;
            if (test_flag) test_flag=0; 
        }
        if (smodel_flag){
            pLogReg->saveParam(smodelFile);
        }
    }
    if (test_flag)
    {
        if (!pLogReg)
        {
            if (!rmodel_flag)
            {
                std::cerr << "No input training database or parameter file specified, cannot do testing." << std::endl;
                return 1;
            }
            else
            {
                pLogReg = new LogReg(0);
                pLogReg->readParam(rmodelFile);
            }
        }
        if (pLogReg)
        {
            SvmDoc tdoc(testFile);
            std::vector<int> labels;
            pLogReg->test(tdoc,labels);
            int numWrong=0;
            for (unsigned int i=0; i<labels.size(); i++)
            {
                if (labels[i]!=tdoc.label[i]) numWrong++;
            }
            std::cout << "NumWrong: " << numWrong << ":" << labels.size() << std::endl;
        }
    }
    if (!pLogReg) delete pLogReg;
}
