#include "Normal.hh"
#include "StudentT.hh"
#include "Gaussian.hh"
#include "SPGaussian.hh"
#include "NPGaussian.hh"
#include "WatsonNadaraya.hh"
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <Eigen/Dense>
#include <boost/math/distributions/students_t.hpp>
#include <boost/math/distributions/normal.hpp>
#include "time.h"

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include "getopt.h"
#else 
#include <unistd.h>
#endif 

static int verbose_flag;
static int bimodel_flag;
static int normal_flag;
static char help_msg[] = "Usage: gof [-h] [-f visfile] [--verbose]\n\
  -h [ --help ]: print this help.\n\
  -f [ --visfile ] filename: set the file name to store visualization data generated for visualization.\n\
  -p [ --lower_p ] lower_p: set the lower bound for spgaussian.\n\
  -n [ --num ] number: number of data points to generate.\n\
  -k [ --kwidth ] kernel: width of kernel.\n\
  -e [ --kernel ] kernel_type: kernel type.\n\
  -l [ --tolerance ] tol: tolerance for optimization in NPGaussian. \n\
  -a [ --l2alpha ] alpha: alpha for l2 regularization on mean parameters. \n\
  -d [ --degree ] deg: degree for t distribution. \n\
  -s [ --sigma ] sigma: sigma for normal distribution. \n\
  [ --verbose ]: set verbose flag\n\
  [ --bimodel ]: what kind of t-distribution model should I generate.\n\
  [ --normal ]: whether use normal or t for unimodel experiment.\n\
Example: gof -f\"wsg.den\"\n\
";

int main(int argc, char** argv)
{
    int c;
    static struct option long_options[]=
    {
        {"verbose", no_argument, &verbose_flag, 1},
        {"bimodel", no_argument, &bimodel_flag, 1},
        {"normal", no_argument, &normal_flag, 1},
        {"kernel", required_argument, 0, 'e'},
        {"visfile", required_argument, 0, 'f'},
        {"kernelp", required_argument, 0, 'p'},
        {"tolerance", required_argument, 0, 'l'},
        {"l2alpha", required_argument, 0, 'a'},
        {"kwidth", required_argument, 0, 'k'},
        {"num", required_argument, 0, 'n'},
        {"help", no_argument, 0, 'h'},
        {"degree", required_argument, 0, 'd'},
        {"sigma", required_argument, 0, 's'},
        {0,0,0,0}
    };

    int option_index=0;
    int d=1;
    int n=10000;
    int sep=1000;
    int deg = 6;
    double mu1 = -3;
    double mu2 = 3;
    double sigma = 1;
    double kernelp = 0.4;
    double tol = 0.01;
    double l2alpha = 10;
    std::string kernel("gaussian");
    double kernelwidth=1;
    int randomseed=34234;
    std::string visfile("wsg.den");

    int errflg=0;
    while ((c = getopt_long(argc, argv, "hf:p:n:k:e:l:a:d:s:",long_options,&option_index)) != -1)
    {
        switch (c) {
        case 0:
            break;
        case 'f':
            visfile=std::string(optarg);
            break;
        case 'p':
            kernelp = std::atof(optarg);
            break;
        case 'd':
            deg = std::atoi(optarg);
            break;
        case 's':
            sigma = std::atof(optarg);
            break;
        case 'n':
            n = std::atoi(optarg);
            break;
        case 'l':
            tol = std::atof(optarg);
            break;
        case 'a':
            l2alpha = std::atof(optarg);
            break;
        case 'k':
            kernelwidth = std::atof(optarg);
            break;
        case 'e':
            kernel=std::string(optarg);
            break;
        case '?':
            errflg++;
            break;
        default:
            errflg++;
            break;
        }
    }
    if (errflg || argc == 1) {
        std::cout << help_msg << std::endl;
        exit (0);
    }

    by::StudentT tgen = by::StudentT(randomseed);
    by::Normal ngen = by::Normal(randomseed);
    std::srand((unsigned)time(NULL));
    Eigen::MatrixXd data(n,1);

    if (!bimodel_flag) 
    {
        if (!normal_flag)
            data=tgen.TDistRandom(0,deg,n,1);
        else
            data=ngen.NormalRandom(0,sigma,n,1);
    }
    else
    {
        for (int i=0; i<n; i++)
        {
            if (std::rand()/(1.0+RAND_MAX) < 0.5)
            {
                Eigen::MatrixXd tmp =ngen.NormalRandom(mu1,sigma,1,1);
                data(i,0)=tmp(0,0);
            }
            else
            {
                Eigen::MatrixXd tmp =ngen.NormalRandom(mu2,sigma,1,1);
                data(i,0)=tmp(0,0);
            }
        }
    }
    Eigen::MatrixXd density(sep,6);
    density.setZero();
    if (verbose_flag)
        std::cout << data.rows() << " " <<data.cols()<<std::endl;
    boost::numeric::ublas::vector<double> data_boostcopy(n);
    for (int i=0; i<n; i++) data_boostcopy(i)=data(i,0);

    double start=-10;
    double end=10;

    by::SPGaussian spgaussianclassifier;
    spgaussianclassifier.init(1, kernelp, 1, kernelwidth);
    by::Gaussian gaussianclassifier;
    by::WatsonNadaraya wnclassifier(2,kernel);
    wnclassifier.setKernelWidth(kernelwidth);
    by::NPGaussian npGaussianModel;
    npGaussianModel.init(1,kernelp,1,kernelwidth,100000,kernel,tol,l2alpha);

    //by::SPGaussian::SPGaussianParam1d sp_param = spgaussianclassifier.getModel1d(data);
    by::Gaussian::GaussianParam1d gp_param = gaussianclassifier.getModel1d(data);
    by::NPGaussian::NPGaussianParam1d np_param = npGaussianModel.getModel1d(data);

    boost::math::students_t_distribution<double> tdist(deg);
    boost::math::normal_distribution<double> ndist(0,sigma);
    boost::math::normal_distribution<double> ndist1(mu1,sigma);
    boost::math::normal_distribution<double> ndist2(mu2,sigma);

    for (int i=0;i<sep;i++)
    {
        density(i,0)=start+(end-start)/sep*i+(end-start)/sep/2;
        if (!bimodel_flag)
        {
            if (!normal_flag)
                density(i,1)=boost::math::pdf(tdist,density(i,0));
            else
                density(i,1)=boost::math::pdf(ndist,density(i,0));
        }
        else
        {
            density(i,1)=boost::math::pdf(ndist1,density(i,0))/2+boost::math::pdf(ndist2,density(i,0))/2;
        }
        density(i,2)=wnclassifier.kernelweight1d(data_boostcopy,density(i,0));
        density(i,3)=gaussianclassifier.calcPdf1d(density(i,0),gp_param);
        //density(i,4)=spgaussianclassifier.SPGaussianPdf(density(i,0),sp_param);
        //std::cout << sp_param.lambda << std::endl;
        density(i,5)=npGaussianModel.NPGaussianPdf(density(i,0),np_param);
        //std::cout << np_param.lambdas << std::endl;
    }
    std::ofstream outDensity(visfile.c_str());
    for (int i=0;i<sep;i++) 
    {
        for (int j=0; j<6; j++) outDensity << density(i,j) << " ";
        outDensity << std::endl;
    }
    //output the sampled points
    std::ofstream outKernels("kernels.den");
    std::cout << np_param.lambdas << std::endl;
    for (int i=0;i<np_param.kernels.rows();i++) 
    {
        outKernels << np_param.kernels(i) << std::endl;
    }
    //output the loglikelihood for each estimation
    double loglik[5];
    memset(loglik, 0, 5*sizeof(double));
    
    int n_test=100000;
    by::StudentT tgen1=by::StudentT((unsigned)time(NULL));
    Eigen::MatrixXd data_test(n_test,1);

    if (!bimodel_flag)
    {
        if (!normal_flag)
            data_test=tgen.TDistRandom(0,deg,n_test,1);
        else
            data_test=ngen.NormalRandom(0,sigma,n_test,1);
    }
    else
    {
        for (int i=0; i<n_test; i++)
        {
            if (std::rand()/(1.0+RAND_MAX) < 0.5)
            {
                Eigen::MatrixXd tmp =ngen.NormalRandom(mu1,sigma,1,1);
                data_test(i,0)=tmp(0,0);
            }
            else
            {
                Eigen::MatrixXd tmp =ngen.NormalRandom(mu2,sigma,1,1);
                data_test(i,0)=tmp(0,0);
            }
        }
    }
    //boost::numeric::ublas::vector<double> data_test_boostcopy(n_test);
    //for (int i=0; i<n_test; i++) data_test_boostcopy(i)=data_test(i,0);
    for (int i=0;i<data_test.rows();i++)
    {
        if (!bimodel_flag)
        {
            if (!normal_flag)
                loglik[0]+=std::log(boost::math::pdf(tdist,data_test(i,0)));
            else
                loglik[0]+=std::log(boost::math::pdf(ndist,data_test(i,0)));
        }
        else
            loglik[0]+=(std::log(boost::math::pdf(ndist1,data_test(i,0))/2+boost::math::pdf(ndist2,data_test(i,0))/2));
        loglik[1]+=std::log(wnclassifier.kernelweight1d(data_boostcopy,data_test(i,0)));
        loglik[2]+=std::log(gaussianclassifier.calcPdf1d(data_test(i,0),gp_param));
        //loglik[3]+=std::log(spgaussianclassifier.SPGaussianPdf(data_test(i,0),sp_param));
        //std::cout << sp_param.lambda << std::endl;
        loglik[4]+=std::log(npGaussianModel.NPGaussianPdf(data_test(i,0),np_param));
        //std::cout << np_param.lambdas << std::endl;
    }
    std::ofstream outLoglik("loglik.den");
    for (int i=0;i<5;i++) 
    {
        outLoglik << loglik[i] << std::endl;
    }
    int nnz=0;
    for (int i=0; i<np_param.lambdas.size();i++)
        if (np_param.lambdas(i)!=0) nnz++;
    outLoglik << nnz << std::endl;

}
