//This file uses boost library for random number generator.

#include "Normal.hh"
//#include <boost/numeric/ublas/matrix_proxy.hpp>
//#include <Eigen/Dense>
//#include <boost/numeric/ublas/io.hpp>
//using namespace boost::numeric::ublas;

#include <Eigen/Eigenvalues>
#include <cmath>

namespace by{
    
    Normal::Normal(base_generator_result_type seed) : generator_(seed),seed_(seed)
    {
        ;
    }

    Eigen::MatrixXd Normal::NormalRandom(double mu=0, double sigma=1,
                                        int nrow=1, int ncol=1)
    {
        //base_generator_type generator(seed_);
        gen_type normalgen = gen_type(generator_,boost::normal_distribution<>(mu,sigma));
        boost::generator_iterator<gen_type>normalgen_iter(&normalgen);
        Eigen::MatrixXd m(nrow,ncol);
        for (int i=0; i < nrow; i++)
        {
            for (int j=0; j < ncol; j++)
            {
                m(i,j) = *normalgen_iter++;
                //std::cout << m(i,j) << std::endl;
            }
        }
        return m;
    }

    Eigen::MatrixXd Normal::MultNormalRandom(
        const Eigen::VectorXd& mu,
        const Eigen::MatrixXd& sigma,
        const int& d,
        const int& n)
    {
        if ( d == 1 )
        {
            return NormalRandom(mu(0), sigma(0,0), n, d);
        }
        else
        {
            Eigen::MatrixXd m = NormalRandom(0,1,d,n);
            //std::cout << m << std::endl;
            //Eigen::MatrixXd s(d,d);
            //for (int i=0; i<d; i++)
            //    for (int j=0; j<d; j++)
            //        s(i,j)=sigma(i,j);
            Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> eigensolver(sigma);
            Eigen::MatrixXd D(d,d);
            for (int i=0; i<d; i++)
                for (int j=0; j<d; j++)
                    D(i,j)=eigensolver.eigenvectors()(i,j);
            //std::cout << D << std::endl;
//             for (int i=0; i<d; i++)
//             {
//                 matrix_column<matrix<double> > Dc (D,i);
//                 double n = norm_2(Dc);
//                 Dc = Dc * (1/n);
//             }
            Eigen::MatrixXd V(d,d);
            for (int i=0; i<d; i++) for (int j=0;j<d; j++) V(i,j)=0;
            for (int i=0; i<d; i++) V(i,i)=std::sqrt(eigensolver.eigenvalues()(i));
            V = D*V;
            //for (int i=0; i<n; i++)
            //{
            //    matrix_column<matrix<double> > mc(m, i);
            //    mc = prod(V,mc);
            //}
            m = V*m;
            //m = prod(V,mt); wrong, only mult first 2.
            for (int i=0; i<n; i++)
            {
                m.col(i) = m.col(i) + mu;
            }
            return m.transpose();
        }
    }

}
