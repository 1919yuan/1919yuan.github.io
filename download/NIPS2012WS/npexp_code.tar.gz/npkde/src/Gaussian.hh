#ifndef __Gaussian_h__
#define __Gaussian_h__

#include <Eigen/Dense>
#include <string>
#include <vector>

namespace by{
    class Gaussian{
    public:
        typedef struct{
            double mu;
            double sigma;
        } GaussianParam1d;
        typedef struct{
            Eigen::VectorXd mu;
            Eigen::MatrixXd sigma;
        } GaussianParamNd;
        Gaussian();
        Gaussian(int nc);
        void setVerbose(){verbose_=true;};
        std::vector<int> classify(const Eigen::MatrixXd& x_train, const std::vector<int>& y_train, const Eigen::MatrixXd& x_test);
        GaussianParam1d getModel1d(const Eigen::MatrixXd& x);
        int calcMaxPdf1d(double x, std::vector<GaussianParam1d>& params);
        double calcPdf1d(double x, GaussianParam1d& param);
        //GaussianParamNd getModelNd(const Eigen::MatrixXd& x);

    private:
        bool verbose_;
        int nc_;
    };
}

#endif
