#include "Gaussian.hh"
#include <Eigen/Dense>
#include <vector>
#include <cmath>
#include <boost/math/distributions/normal.hpp>


namespace by{

    Gaussian::Gaussian():nc_(2),verbose_(false)
    {
        ;
    }

    Gaussian::Gaussian(int nc):verbose_(false), nc_(nc)
    {
        ;
    }
    std::vector<int> Gaussian::classify(const Eigen::MatrixXd& x_train, 
        const std::vector<int>& y_train, const Eigen::MatrixXd& x_test)
    {
        std::vector<Eigen::MatrixXd*> x_train_split;
        std::vector<int> count(nc_);
        for (int i=0;i<nc_;i++) count[i]=0;
        for (unsigned int i=0;i<y_train.size();i++)
            count[y_train[i]]+=1;
        for (int i=0;i<nc_;i++)
        {
            Eigen::MatrixXd* mptr = new Eigen::MatrixXd(count[i],x_train.cols());
            x_train_split.push_back(mptr);
        }
        for (int i=0;i<nc_;i++) count[i]=0;
        for (unsigned int i=0;i<y_train.size();i++)
        {
            Eigen::MatrixXd* a = x_train_split[y_train[i]];
            a->row(count[y_train[i]]++)=x_train.row(i);
        }
        std::vector<int> y_test(x_test.rows());
        for (int i=0; i < x_test.rows(); i++) y_test[i]=0;

        if (x_test.cols()==1)
        {
            std::vector<GaussianParam1d> params(nc_);
            for (int i=0; i<nc_; i++)
            {
                params[i]=getModel1d(*x_train_split[i]);
            }
            for (int i=0;i<x_test.rows();i++)
            {
                double x = x_test(i,0);
                y_test[i]=calcMaxPdf1d(x,params);
            }
        }
        else{
            //TODO;
        }
        return y_test;
    }

    Gaussian::GaussianParam1d Gaussian::getModel1d(const Eigen::MatrixXd& x)
    {
        GaussianParam1d gp;
        double mean = 0;
        double sd = 0;
        for (int i=0; i < x.rows(); i++)
        {
            mean += x(i,0);
        }
        mean /= x.rows();
        for (int i=0; i < x.rows(); i++)
        {
            sd += (x(i,0)-mean)*(x(i,0)-mean);
        }
        sd /= x.rows();
        sd = std::sqrt(sd);
        gp.mu = mean;
        gp.sigma = sd;
        return gp;
    }

    int Gaussian::calcMaxPdf1d(double x, std::vector<GaussianParam1d>& params)
    {
        std::vector<double> scores(params.size());
        for (unsigned int i=0; i<params.size(); i++)
        {
            boost::math::normal_distribution<double> normal_param(params[i].mu,params[i].sigma);
            scores[i]=boost::math::pdf(normal_param, x);
        }
        int res = 0;
        for (unsigned int i=0; i<scores.size(); i++)
        {
            if (scores[i]>scores[res]) res = i;
        }
        return res;
    }

    double Gaussian::calcPdf1d(double x, GaussianParam1d& param)
    {        
        boost::math::normal_distribution<double> normal_param(param.mu,param.sigma);
        return boost::math::pdf(normal_param, x);
    }
}
