#include "SPGaussian.hh"
#include "Normal.hh"
#include <Eigen/Dense>
#include <vector>
#include <cmath>
#include <iostream>
#include <boost/math/distributions/normal.hpp>

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include <random>
#else
#include <stdlib.h>
#endif

namespace by{

    SPGaussian::SPGaussian():verbose_(false)
    {
        seed_ = 2341;
        kerID_ = 1;
        init(2,0.1,1,0.1);
    }

    SPGaussian::SPGaussian(int nc, int seed):verbose_(false)
    {
        seed_ = seed;
        init(nc,0.1,1,0.1);
    }
    void SPGaussian::init(int nc, double p_lower, double np_portion, double epsilon)
    {
        double maxkerfunc = 1/std::sqrt(2*3.1415926);
        nc_=nc;
        p_lower_=p_lower*maxkerfunc;
        np_portion_=np_portion;
        epsilon_=epsilon;
    }
    std::vector<int> SPGaussian::classify(const Eigen::MatrixXd& x_train, 
        const std::vector<int>& y_train, const Eigen::MatrixXd& x_test)
    {
        //std::cout << x_train;
        std::vector<Eigen::MatrixXd*> x_train_split;
        std::vector<int> count(nc_);
        for (int i=0;i<nc_;i++) count[i]=0;
        for (unsigned int i=0;i<y_train.size();i++)
            count[y_train[i]]+=1;
        for (int i=0;i<nc_;i++)
        {
            Eigen::MatrixXd* mptr = new Eigen::MatrixXd(count[i],x_train.cols());
            x_train_split.push_back(mptr);
        }
        for (int i=0;i<nc_;i++) count[i]=0;
        for (unsigned int i=0;i<y_train.size();i++)
        {
            Eigen::MatrixXd* a = x_train_split[y_train[i]];
            a->row(count[y_train[i]]++)=x_train.row(i);
        }
        std::vector<int> y_test(x_test.rows());
        for (int i=0; i < x_test.rows(); i++) y_test[i]=0;

        if (x_test.cols()==1)
        {
            std::vector<SPGaussianParam1d> params(nc_);
            for (int i=0; i<nc_; i++)
            {
                params[i]=getModel1d(*x_train_split[i]);
            }
            for (int i=0;i<x_test.rows();i++)
            {
                double x = x_test(i,0);
                y_test[i]=calcMaxPdf1d(x,params);
            }
        }
        else{
            //TODO;
        }
        for (int i=0; i<nc_; i++) delete x_train_split[i];
        return y_test;
    }

    SPGaussian::SPGaussianParam1d SPGaussian::getModel1d(const Eigen::MatrixXd& x)
    {
        //std::cout << x;
        SPGaussianParam1d sgp;
        double mean = 0;
        double sd = 0;
        for (int i=0; i < x.rows(); i++)
        {
            mean += x(i,0);
        }
        mean /= x.rows();
        for (int i=0; i < x.rows(); i++)
        {
            sd += (x(i,0)-mean)*(x(i,0)-mean);
        }
        sd /= x.rows();
        sd = std::sqrt(sd);
        sgp.mu = mean;
        sgp.sigma = sd;
        findKernels1d(x,np_portion_,epsilon_,sgp);
        //coordinate descent loop;
        sgp.lambda = 0;
        double p = pKernels1d(sgp);
        double delta_plus = std::log((p_lower_ * (1-p))/(1-p_lower_)/p);
        while ( p < p_lower_ && std::fabs(delta_plus)> 0.0001)
        {
            if (sgp.lambda + delta_plus > 0) sgp.lambda += delta_plus;
            else sgp.lambda = 0;
            p = pKernels1d(sgp);
            delta_plus = std::log((p_lower_ * (1-p))/(1-p_lower_)/p);
        }
        return sgp;
    }

    double SPGaussian::pKernels1d(SPGaussianParam1d& sgp)
    {
        if (kerID_==0)
        {
            boost::math::normal_distribution<double> normal_dist(sgp.mu,sgp.sigma);
            double pKernels = 0;
            for (int i=0; i<sgp.intervals.rows(); i++)
            {
                pKernels+=boost::math::cdf(normal_dist, sgp.kernels(i,1))-boost::math::cdf(normal_dist, sgp.kernels(i,0));
            }
            sgp.par = ((std::exp(sgp.lambda)-1)*pKernels+1);
            return std::exp(sgp.lambda)*pKernels/sgp.par;
        }
        else if (kerID_==2)
        {
            boost::math::normal_distribution<double> normal_dist(sgp.mu,sgp.sigma);
            double pKernels = 0;
            pKernels+=boost::math::cdf(normal_dist, sgp.kernels(0));
            pKernels+=1-boost::math::cdf(normal_dist,sgp.kernels(1));
            sgp.par = ((std::exp(sgp.lambda)-1)*pKernels+1);
            return std::exp(sgp.lambda)*pKernels/sgp.par;
        }
        else
        {//using Monte-Carlo method
            by::Normal ngen = by::Normal(seed_);
            int MC_NUM=1000;
            Eigen::MatrixXd data=ngen.NormalRandom(sgp.mu,sgp.sigma,MC_NUM,1);
            Eigen::VectorXd kernelwight(MC_NUM);
            double totexpgx = 0;
            double totexpgxgx = 0;
            for (int i=0; i<MC_NUM; i++)
            {
                kernelwight(i)=calcKernels(data(i,0),sgp);
                totexpgx+=std::exp(sgp.lambda*kernelwight(i));
                totexpgxgx+=std::exp(sgp.lambda*kernelwight(i))*kernelwight(i);
            }
            totexpgx/=MC_NUM;
            totexpgxgx/=MC_NUM;
            sgp.par = totexpgx;
            return totexpgxgx;
        }
    }

    void SPGaussian::findKernels1d(const Eigen::MatrixXd& x, double portion, double epsilon, SPGaussianParam1d& sgp)
    {
        if (kerID_==0 || kerID_ == 2){
            //using ball constraint kernel, concatenating overlapping inverval
            assert(x.cols()==1);
            assert(portion <=1 && portion >0);
            srand(seed_);
            std::vector<double> x_chosen;
            for (int i=0; i<x.rows(); i++)
            {
                if (rand() <= portion*((double)RAND_MAX+1) && std::fabs(x(i,0)-sgp.mu) > sgp.sigma/2 )
                    x_chosen.push_back(x(i,0));
            }
            if (x_chosen.empty()) 
            {
                std::cerr << "No kernels were select from training set, check your portion parameter, make sure it is not too small." << std::endl;
                exit(-1);
            }
            std::sort(x_chosen.begin(),x_chosen.end());
            if (kerID_==0)
            {
            std::vector<double> start;
            std::vector<double> end;
            start.push_back(x_chosen[0]-epsilon);
            for (unsigned int i=1; i<x_chosen.size(); i++)
            {
                if (x_chosen[i-1]+epsilon > x_chosen[i])
                    continue;
                else
                {
                    end.push_back(x_chosen[i-1]+epsilon);
                    start.push_back(x_chosen[i]-epsilon);
                }
            }
            end.push_back(x_chosen[x_chosen.size()-1]+epsilon);
            Eigen::MatrixX2d kernels(start.size(),2);
            for (unsigned int i=0; i<start.size(); i++)
            {
                kernels(i,0)=start[i];
                kernels(i,1)=end[i];
            }
            sgp.intervals=kernels;
            }
            else{
            if (x_chosen.size()>10)
                sgp.kernels=Eigen::Vector2d(x_chosen[x_chosen.size()/10],x_chosen[x_chosen.size()*9/10]);
            }
        }
        else{
            srand(seed_);
            std::vector<double> x_chosen;
            for (int i=0; i<x.rows(); i++)
            {
                if (rand() <= portion*((double)RAND_MAX+1))// && std::fabs(x(i,0)-sgp.mu) > sgp.sigma/2 )
                    x_chosen.push_back(x(i,0));
            }
            if (x_chosen.empty()) 
            {
                std::cerr << "No kernels were select from training set, check your portion parameter, make sure it is not too small." << std::endl;
                exit(-1);
            }
            sgp.kernels=Eigen::VectorXd(x_chosen.size());
            for (unsigned int i=0; i<x_chosen.size(); i++) sgp.kernels(i)=x_chosen[i];
        }
    }

    double SPGaussian::calcKernels(double x, SPGaussianParam1d param)
    {
        if (kerID_==0)
        {
            for (int i=0; i<param.intervals.rows(); i++)
            {
                if ( x <= param.intervals(i,1) && x >= param.intervals(i,0))
                    return 1;
            }
            return 0;
        }
        else if (kerID_==2)
        {
            if (x <= param.kernels(0) || x >= param.kernels(1))
                return 1;
            else 
                return 0;
        }
        else
        {
            double PI = 3.1415926535897;
            double weight = 0;
            for (int i=0;i<param.kernels.size(); i++)
            {
                double y=param.kernels(i);
                weight+=1/std::sqrt(2*PI)*std::exp(-0.5*(x-y)*(x-y)/epsilon_/epsilon_);
            }
            return weight/param.kernels.size();
        }
    }

    int SPGaussian::calcMaxPdf1d(double x, std::vector<SPGaussianParam1d>& params)
    {
        std::vector<double> scores(params.size());
        for (unsigned int i=0; i<params.size(); i++)
        {
            boost::math::normal_distribution<double> normal_param(params[i].mu,params[i].sigma);
            scores[i]=boost::math::pdf(normal_param, x)*std::exp(params[i].lambda*calcKernels(x,params[i]))/params[i].par;
        }
        int res = 0;
        for (unsigned int i=0; i<scores.size(); i++)
        {
            if (scores[i]>scores[res]) res = i;
        }
        return res;
    }

    double SPGaussian::SPGaussianPdf(double x, const SPGaussianParam1d& param)
    {
        boost::math::normal_distribution<double> normal_param(param.mu,param.sigma);
        return boost::math::pdf(normal_param, x)*std::exp(param.lambda*calcKernels(x,param))/param.par;
    }
}
