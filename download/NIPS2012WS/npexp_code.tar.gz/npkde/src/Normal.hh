#ifndef __Normal_h__
#define __Normal_h__

#include <boost/random/normal_distribution.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/generator_iterator.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/random.hpp>
#include <Eigen/Dense>

//using namespace boost::numeric::ublas;

namespace by{
    class Normal{
    private:
        typedef boost::mt19937 base_generator_type;
        typedef boost::mt19937::result_type base_generator_result_type;
    public:
        Normal(base_generator_type::result_type seed);
        Eigen::MatrixXd NormalRandom(double mu, double sigma, 
                                    int nrow, int ncol);
        Eigen::MatrixXd MultNormalRandom(const Eigen::VectorXd& mu,
                                         const Eigen::MatrixXd& sigma,
                                         const int& d,
                                         const int& n);
                                        
    private:
        typedef boost::variate_generator<base_generator_type&, 
            boost::normal_distribution<> > gen_type;
        base_generator_type generator_;
        base_generator_result_type seed_;
    };
}

#endif
