//For the final project, currently this file is not ported in Eigen library. It still uses boost library.
//TODO: change this file to use Eigen library, but don't know how to handle the shared_ptr part yet.

#include "WatsonNadaraya.hh"
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <limits>
#include <ctime>
#include <fstream>
#include <vector>
#include <cmath>

namespace by{

    WatsonNadaraya::WatsonNadaraya():nc_(2),kernel_(KNN),verbose_(false),kernel_width_(1)
    {
        ;
    }

    WatsonNadaraya::WatsonNadaraya(int nc, const std::string& kt):verbose_(false),kernel_width_(1)
    {
        init(nc,kt);
    }

    void WatsonNadaraya::init(int nc, const std::string& kt)
    {
        nc_ = nc;
        kernel_width_=1;
        if (!kt.compare("knn"))
        {
            kernel_ = KNN;
        }
        else if (!kt.compare("gaussian"))
        {
            kernel_ = GAUSSIAN;
        }
        else if (!kt.compare("laplacian"))
        {
            kernel_ = LAPLACIAN;
        }
        else kernel_ = EPACHEV;
    }
    vector<int> WatsonNadaraya::classify(const matrix<double>& x_train, const vector<int>& y_train, const matrix<double>& x_test)
    {
        std::vector<matrixdPtr> x_train_split;
        vector<int> count(nc_);
        for (int i=0;i<nc_;i++) count(i)=0;
        for (unsigned int i=0;i<y_train.size();i++)
            count(y_train(i))+=1;
        for (int i=0;i<nc_;i++)
        {
            matrixdPtr mdPtr(new matrix<double>(count(i),x_train.size2()));
            //(*mdPtr)(0,0)=4;
            //std::cout << "good" << std::endl;
            x_train_split.push_back(mdPtr);
            //std::cout << (matrix<double> &)(*mdPtr) << std::endl;
        }
        for (int i=0;i<nc_;i++) count(i)=0;
        for (unsigned int i=0;i<y_train.size();i++)
        {
            matrixdPtr a = x_train_split[y_train(i)];
            //std::cout << (*a) << std::endl;
            //std::cout << count(i) << std::endl;
            matrix_row<matrix<double> >ar(*a,count(y_train(i))++);
            //std::cout << "Here copying split data" << std::endl;
            const matrix_row<const matrix<double> > xr = row(x_train,i);
            //std::cout << x_train.size1() << " " << i << std::endl;
            ar=xr;
        }
        vector<int> y_test(x_test.size1());
        //std::cout << "Here making wn" << std::endl;
        for (unsigned int i=0;i<x_test.size1();i++)
        {
            const matrix_row<const matrix<double> >xtr = row(x_test,i);
            vector<double> scores=wnkernelweights(x_train_split,xtr);
            y_test(i)=index_norm_inf(scores);
        }
        return y_test;
    }
    
    vector<double> WatsonNadaraya::wnkernelweights(const std::vector<matrixdPtr> x_train_split,
        const matrix_row<const matrix<double> >& xtr )
    {
        vector<double> weights(x_train_split.size());
        for (unsigned int i=0; i<x_train_split.size(); i++)
            weights(i)=0;
        for (unsigned int i=0; i<x_train_split.size(); i++)
        {
            const_matrixdPtr a = x_train_split[i];
            //matrix<double>& pa = *a
            for (unsigned int j=0; j<a->size1(); j++)
            {
                const matrix_row<const matrix<double> > ar = row(*a,j);
                weights(i)+=kernel(ar, xtr);
            }
        }
        return weights;
    }
    
    double WatsonNadaraya::kernel(const matrix_row<const matrix<double> >&x,
                                  const matrix_row<const matrix<double> >&y)
    {
        double PI = 3.1415926535897932;
        if (kernel_ == KNN)
        {
            if (norm_inf(x-y)<(kernel_width_)) return 0.5/std::pow(kernel_width_,(int)x.size());
            else return 0;
        }
        else if (kernel_ == GAUSSIAN)
        {
            return 1/std::sqrt(2*PI)*std::exp(-0.5*norm_2(x-y)*norm_2(x-y)/kernel_width_/kernel_width_)/std::pow(kernel_width_,(int)x.size());
        }
        else if (kernel_==LAPLACIAN)
        {
            return -0.5*std::exp(-norm_1(x-y)/kernel_width_)/std::pow(kernel_width_,(int)x.size());
        }
        else //epachenov
        {
            double u = norm_1(x-y);
            if (u < kernel_width_)
            {
                return 0.75*(1-(u/kernel_width_)*(u/kernel_width_));
            }
            else return 0;
        }
    }

    double WatsonNadaraya::kernelweight1d(
        const vector<double>& x_train,
        const double& x )
    {
        double weight=0;
        for (unsigned int i=0; i<x_train.size(); i++)
        {
            weight+=kernel1d(x_train(i), x);
        }
        return weight/x_train.size();
    }

    double WatsonNadaraya::kernel1d(
        const double& x,
        const double& y)
    {
        double PI = 3.1415926535897932;
        if (kernel_ == KNN)
        {
            if (std::fabs(x-y)<(kernel_width_)) return 0.5/kernel_width_;
            else return 0;
        }
        else if (kernel_ == GAUSSIAN)
        {
            return 1/std::sqrt(2*PI)*std::exp(-0.5*(x-y)*(x-y)/kernel_width_/kernel_width_)/kernel_width_;
        }
        else if (kernel_==LAPLACIAN)
        {
            return -0.5*std::exp(-std::fabs(x-y)/kernel_width_)/kernel_width_;
        }
        else //epachenov
        {
            double u = std::fabs(x-y);
            if (u < kernel_width_)
            {
                return 0.75*(1-(u/kernel_width_)*(u/kernel_width_))/kernel_width_;
            }
            else return 0;
        }
    }
}
