#include "Normal.hh"
#include "StudentT.hh"
#include "Gaussian.hh"
#include "SPGaussian.hh"
#include "WatsonNadaraya.hh"
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <Eigen/Dense>
#include <boost/math/distributions/students_t.hpp>

#if defined WIN32 || WIN64 || _WIN32 || _WIN64
#include "getopt.h"
#else 
#include <unistd.h>
#endif 

static int verbose_flag;
static int bimodel_flag;
static char help_msg[] = "Usage: gof [-h] [-f visfile] [--verbose]\n\
  -h [ --help ]: print this help.\n\
  -f [ --visfile ] filename: set the file name to store visualization data generated for visualization.\n\
  -p [ --lower_p ] lower_p: set the lower bound for spgaussian.\n\
  -n [ --num ] number: number of data points to generate.\n\
  [ --verbose ]: set verbose flag\n\
  [ --bimodel ]: what kind of t-distribution model should I generate.\n\
Example: gof -f\"wsg.den\"\n\
";

int main(int argc, char** argv)
{
    int c;
    static struct option long_options[]=
    {
        {"verbose", no_argument, &verbose_flag, 1},
        {"bimodel", no_argument, &bimodel_flag, 1},
        {"visfile", required_argument, 0, 'f'},
        {"kernelp", required_argument, 0, 'p'},
        {"num", required_argument, 0, 'n'},
        {"help", no_argument, 0, 'h'},
        {0,0,0,0}
    };

    int option_index=0;
    int d=1;
    int n=10000;
    int sep=1000;
    int deg = 3;
    double kernelp = 0.4;
    std::string kernel("knn");
    double kernelwidth=1;
    int randomseed=34234;
    std::string visfile("wsg.den");

    int errflg=0;
    while ((c = getopt_long(argc, argv, "hf:p:n:",long_options,&option_index)) != -1)
    {
        switch (c) {
        case 0:
            break;
        case 'f':
            visfile=std::string(optarg);
            break;
        case 'p':
            kernelp = std::atof(optarg);
            break;
        case 'n':
            n = std::atoi(optarg);
            break;
        case '?':
            errflg++;
            break;
        default:
            errflg++;
            break;
        }
    }
    if (errflg || argc == 1) {
        std::cout << help_msg << std::endl;
        exit (0);
    }

    by::StudentT tgen = by::StudentT(randomseed);

    Eigen::MatrixXd data=tgen.TDistRandom(0,deg,n,1);
    if (bimodel_flag)
    {
        for (int i=0; i< n/2; i++) data(i,0)+=3;
        for (int i=n/2+1; i< n; i++) data(i,0)-=3;
    }
    Eigen::MatrixXd density(sep,5);
    if (verbose_flag)
        std::cout << data.rows() << " " <<data.cols()<<std::endl;
    boost::numeric::ublas::vector<double> data_boostcopy(n);
    for (int i=0; i<n; i++) data_boostcopy(i)=data(i,0);

    boost::math::students_t_distribution<double> tdist(deg);
    double start=-10;
    double end=10;

    by::SPGaussian spgaussianclassifier;
    spgaussianclassifier.init(2, kernelp, 1, 1);
    by::Gaussian gaussianclassifier;
    by::WatsonNadaraya wnclassifier(2,"gaussian");

    by::SPGaussian::SPGaussianParam1d sp_param = spgaussianclassifier.getModel1d(data);
    by::Gaussian::GaussianParam1d gp_param = gaussianclassifier.getModel1d(data);

    for (int i=0;i<sep;i++)
    {
        density(i,0)=start+(end-start)/sep*i+(end-start)/sep/2;
        if (!bimodel_flag)
            density(i,1)=boost::math::pdf(tdist,density(i,0));
        else
            density(i,1)=boost::math::pdf(tdist,density(i,0)+3)/2+boost::math::pdf(tdist,density(i,0)-3)/2;
        density(i,2)=wnclassifier.kernelweight1d(data_boostcopy,density(i,0));
        density(i,3)=gaussianclassifier.calcPdf1d(density(i,0),gp_param);
        density(i,4)=spgaussianclassifier.SPGaussianPdf(density(i,0),sp_param);
    }
    std::ofstream outDensity(visfile.c_str());
    for (int i=0;i<sep;i++) 
    {
        for (int j=0; j<5; j++) outDensity << density(i,j) << " ";
        outDensity << std::endl;
    }
}
