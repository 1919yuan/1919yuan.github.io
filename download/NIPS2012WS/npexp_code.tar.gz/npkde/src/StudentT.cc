//This file uses boost library for random number generator.

#include "StudentT.hh"
//#include <boost/numeric/ublas/matrix_proxy.hpp>
//#include <Eigen/Dense>
//#include <boost/numeric/ublas/io.hpp>

#include <Eigen/Eigenvalues>
#include <cmath>

namespace by{
    
    StudentT::StudentT(base_generator_result_type seed) : generator_(seed),seed_(seed)
    {
        ;
    }

    Eigen::MatrixXd StudentT::TDistRandom(double mu, int deg=1,int nrow=1, int ncol=1)
    {
        //base_generator_type generator(seed_);
        gen_type student_t_gen = gen_type(generator_,boost::random::student_t_distribution<>(deg));
        boost::generator_iterator<gen_type>student_t_gen_iter(&student_t_gen);
        Eigen::MatrixXd m(nrow,ncol);
        for (int i=0; i < nrow; i++)
        {
            for (int j=0; j < ncol; j++)
            {
                m(i,j) = mu+*student_t_gen_iter++;
                //std::cout << m(i,j) << std::endl;
            }
        }
        return m;
    }

    Eigen::MatrixXd StudentT::MultTDistRandom(
        const Eigen::VectorXd& mu,
        const Eigen::MatrixXd& sigma,
        const int& deg,
        const int& d,
        const int& n)
    {
        //Not implemented yet
        return Eigen::MatrixXd::Random(n,d);
    }

}
