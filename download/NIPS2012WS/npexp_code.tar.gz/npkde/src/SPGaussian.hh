#ifndef __SPGaussian_h__
#define __SPGaussian_h__

#include <Eigen/Dense>
#include <string>
#include <vector>

namespace by{
    class SPGaussian{
    public:
        typedef struct{
            double mu;
            double sigma;
            Eigen::MatrixX2d intervals;
            Eigen::VectorXd kernels;
            double lambda;
            double par;
        } SPGaussianParam1d;
        //typedef struct{
        //    Eigen::VectorXd mu;
        //    Eigen::MatrixXd sigma;
        //} SPGaussianParamNd;
        SPGaussian();
        SPGaussian(int nc, int seed);
        void init(int nc, double p_lower, double np_portion, double epsilon);
        void setVerbose(){verbose_=true;};
        std::vector<int> classify(const Eigen::MatrixXd& x_train, const std::vector<int>& y_train, const Eigen::MatrixXd& x_test);
        SPGaussianParam1d getModel1d(const Eigen::MatrixXd& x);
        int calcMaxPdf1d(double x, std::vector<SPGaussianParam1d>& params);
        double SPGaussianPdf(double x, const SPGaussianParam1d& param);
        //GaussianParamNd getModelNd(const Eigen::MatrixXd& x);

    private:
        void findKernels1d(const Eigen::MatrixXd& x, double portion, double epsilon, SPGaussianParam1d& sgp);
        double calcKernels(double x, SPGaussianParam1d param);
        double pKernels1d(SPGaussianParam1d& sgp);
        bool verbose_;
        int nc_;
        double p_lower_;
        double np_portion_;
        double epsilon_;
        int seed_;
        int kerID_;
    };
}

#endif
