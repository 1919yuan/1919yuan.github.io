#!/bin/sh

if [[ ! -d build ]]; then
	mkdir build
fi
cd build
cmake -G"Unix Makefiles" -DCMAKE_MAKE_PROGRAM:FILEPATH=/usr/bin/make ..
make
cd ..
